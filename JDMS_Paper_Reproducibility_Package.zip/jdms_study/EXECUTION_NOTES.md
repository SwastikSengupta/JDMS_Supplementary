# Execution notes

The retained execution record dates the primary exact study and both Monte Carlo studies to 10 October 2026. No operational military dataset was used. The author reports subsequent independent expert review of the mathematical content. The locally frozen protocol is not a preregistration.

## Changes after the initial run

The reporting of zero-event Monte Carlo tails was corrected: a sample with zero variance is no longer assigned a standardized error of zero or an informative confidence interval. Such intervals and standardized errors are left missing, and exact mathematical values remain available. This is a reporting correction; the random paths, selected reserves, exact bounds, and nonzero-variance intervals are unchanged.

A finite circular-trace witness was added after the exact results, to make the non-identification argument checkable using integer counts. It is an illustrative verification construction, not an independently selected confirmatory scenario. Paired capacity-effect summaries were computed from the original stored replications without changing any paths.

All 324 pre-specified parameter cells and all 48 finite-horizon cells are retained. No grid cells were discarded. The illustrative laws are intentionally chosen counterexamples, not estimated deployment frequencies. The maximum-entropy baseline was added to the protocol before execution to give a comparator inside the bounded moment class.

## Authorship and release

The author's corrected account is authoritative for authorship: the author conducted the research and prepared the original manuscript. AI assistance in that work was limited to grammar correction, language flow, and mathematics checking before independent expert review. Earlier descriptions of broader AI involvement were inaccurate and have been replaced throughout this package. The current literature revision separately records assistance from ChatGPT, Consensus, and Undermind with literature discovery, source checking, and related-work and reference editing. No public deposit or journal submission was made.

## Formatting revision after author verification

The scientific claims, experimental design, simulated paths, and reported numerical results were retained. All 39 numerical verification checks passed again. The manuscript was typeset as a two-column PDF using the unchanged Sage journal class and compared with a published JDMS layout. The editable Word manuscript follows the journal's requested sequence with tables and figures after the text and references. The acknowledgment has now been corrected to the author-supplied account and updated to describe the literature assistance in this revision; AI is not an author. The Cummings reference was changed to the first three authors plus “et al.” in accordance with Sage Vancouver style. The author confirmed no funding and no conflicts of interest. ORCID 0009-0002-9414-7443 is included in both manuscript formats.

Formatting sources checked on 10 October 2026: https://journals.sagepub.com/author-instructions/dms ; https://www.sagepub.com/reference-style-sage-vancouver-msg ; https://www.sagepub.com/journals/publication-ethics-policies/artificial-intelligence-policy . The visual reference was Davis and Bracken, “Artificial intelligence for wargaming and modeling,” DOI 10.1177/15485129211073126, via the RAND-hosted author copy. This article was used for layout only and was not added to the study's scientific bibliography.

## Analytical and source audit during final revision

After the original numerical runs, a quadratic upper certificate was derived for constant unit demand, full restoration, mean normal spell 16, and positive integer outage duration with mean 4 and second moment 28. It covers every duration without a maximum. The certificate and attaining laws prove that the extreme minimum reserves are 4 and 19 units at the 1% threshold. This is a post-run analytical extension, not a preregistered experiment or a new general moment-optimization theorem. Exact rational checks are in `src/verify_certificates.py` and `results/unbounded_certificate.json`. The original simulated paths and numerical experiment results are unchanged.

The original 17 references were checked against primary publisher or institutional records, with DOI registry metadata retrieved for 14. Three DOI registry requests were rate-limited; their primary-source records remain documented. Two relevant references, Corlu et al. and Lam, were added to acknowledge established simulation input-uncertainty and dependence research. Their metadata were also retrieved. Access levels are recorded rather than implying that every cited article was read in full. Issue years are distinguished from earlier online publication years.

The final audit corrected two minor rounded diagnostics: the maximum LP/enumeration gap is 2.10 × 10^-12 requests per cycle, and the maximum daily-verification discrepancy is 1.76 standard errors. The paper now calls the ratio-estimator intervals approximate and pointwise. These corrections do not change any stock decision, reported shortage estimate, random path, or mathematical conclusion. The author reports independent expert review of the mathematical content. The newly revised literature discussion and final submission declarations still require author approval before submission.

## Literature and disclosure revision on 11 October 2026 UTC

Consensus searches and a completed Undermind deep search identified additional work on disrupted inventory, discrete moment and stop-loss bounds, service-constrained inventory, uncertain simulation inputs, and maximum-entropy decisions. Nine published references were added. The source ledger distinguishes full-text inspection from metadata or abstract-level support. No claim of a systematic review or worldwide priority is made.

All 39 retained verification checks and the 119 exact attaining-law checks were rerun successfully in an isolated copy. The original 12-million-cycle and 192,000-path simulations were not rerun in this editorial revision. The exact phase was separately recomputed and compared with retained results, as recorded in the revision audit. Research code and original numerical files were retained.

The frozen protocol's item 1 explicitly adds law E to the experiments, giving 12 law-demand combinations and 48 finite-horizon cells; the older shorthand references to nine combinations and three laws in items 3 and 4 are read with that addition. The frozen protocol has not been silently rewritten.


## Final author declarations

The author supplied ORCID 0009-0002-9414-7443 and confirmed no funding and no conflicts of interest. The final manuscript includes those declarations, removes editorial placeholders, and states demonstrated findings directly while retaining the model assumptions and scientific limits.
