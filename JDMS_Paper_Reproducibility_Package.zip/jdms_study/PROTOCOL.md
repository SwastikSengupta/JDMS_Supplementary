# Computational study specification

Written on 10 October 2026 before the numerical study was executed. This is a timestamped local specification, not a registered protocol. The illustrative distributions were chosen analytically to expose the limits of moment matching. They are constructed benchmarks, not random samples of military systems.

## Primary research question

At an isolated support node with immediate restoration of reserve stock when normal supply returns, do outage models with equal resupply availability, one-step transition probabilities, and outage-duration mean and variance identify the same smallest reserve that meets an unmet-demand target?

## Primary endpoint and claim boundary

The endpoint is the long-run fraction of unit requests that cannot be filled at the time of request. It is a ratio of expected unmet requests to expected total requests per renewal cycle. It is not the probability of at least one stockout, an equipment-readiness percentage, or a probability of mission success. The decision is the smallest integer reserve S with unmet fraction at most epsilon. Main epsilon is 0.01, a study choice rather than a military standard.

The primary claim concerns insufficiency of these input summaries for this reserve decision. No optimal routing, combat outcome, live force calibration, or field validation is claimed. The renewal-reward formula and finite moment linear programming are established tools; novelty is sought in the controlled validation benchmark and its decision-focused use.

## Main benchmark

Independent normal-supply spells U are geometric on positive integers with mean 16 days. Outage D has one of three laws: G, geometric with mean 4; A, 2 days with probability 3/4 or 10 days with probability 1/4; B, 3 days with probability 12/13 or 16 days with probability 1/13. All have E[D]=4 and E[D^2]=28. Demand per day is either exactly 1, Poisson with mean 1, or negative binomial with mean 1 and variance 3. Demand and spell durations are independent. Unfilled requests are lost and not backlogged. Normal supply serves requests and restores the reserve by the end of each normal day. The reserve is full at each outage start.

## Experiments

1. Exact expected-shortage curves, minimum reserves, and cross-evaluation of reserves selected under each law. Include the geometric model as a reference, not as ground truth. Add E, the maximum-entropy distribution on 1 through 32 with the same moments, as a baseline that lies inside the bounded ambiguity set. Include this fourth law in both simulation experiments below (12 cycle combinations and 48 finite-horizon combinations).
2. Tight upper and lower shortage envelopes over integer outage lengths 1 through M with fixed first two moments. Means are 2, 4, 6; variance equals mu*(mu-1); M is 4, 8, or 16 times mu. Availability is 0.70, 0.80, 0.90, or 0.95. Targets are 0.005, 0.01, or 0.02. Three demand laws give 324 design cells. Compare both geometric and maximum-entropy selections with the bounds; the unbounded geometric law is a reference outside the bounded set, while maximum entropy lies inside it. Report all cells. Confirm the main linear-programming envelope independently by exhaustive enumeration of feasible distributions with at most three support points.
3. Monte Carlo verification for all nine law/demand combinations. Use 200 independent batches of 5000 complete cycles, save batch totals, and use a ratio-of-means estimator with a batch-level delta-method 95% t interval. This interval describes Monte Carlo error under known inputs, not field uncertainty. Do not use daily observations as independent replicates.
4. Independent daily simulator with finite replenishment capacity: all three outage laws, deterministic or Poisson demand, 90 or 365 days, capacities 2, 4, or unlimited units/day; 4000 independent replications per cell and common demand/outage paths across reserves. Start in a new normal spell with full stock. On a normal day, receive C, fill demand from stock plus arrivals, and cap ending stock at S; unlimited arrivals restore S after meeting demand. On a disrupted day, use stock only. Report finite-horizon ratios and replication-level uncertainty. The renewal certificate does not apply when reserves fail to refill.

## Verification

Check exact moments, probability mass, nonnegative demand and inventory, unmet/fulfilled conservation, zero-stock and large-stock limits, monotonic shortage in reserve, linear-programming primal/dual feasibility, independent vertex-enumeration agreement, and independent daily-simulator agreement with complete-cycle calculations within Monte Carlo tolerance. Keep failed checks and corrections in the execution log if any occur.

## Analysis discipline

Use fixed seeds derived from a master seed and explicit experiment indices. Do not tune parameters to obtain a desired Monte Carlo significance. Exact results carry no confidence intervals. Distinguish a stress grid from a population sample: a percentage of failed grid cells is descriptive and is not a prevalence estimate. Disclose the maximum-duration assumption in every robust-stock result. Save all code, configurations, raw batch/replicate aggregates, environment versions, and SHA-256 checksums. Report any changes to this specification in a deviations section.
