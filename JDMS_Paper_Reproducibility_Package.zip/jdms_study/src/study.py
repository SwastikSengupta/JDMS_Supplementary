"""Moment-matched resupply audit. All inputs are constructed, nonoperational benchmarks.

Run: python src/study.py --phase exact|cycles|finite|all
Dependencies: numpy, scipy, pandas. No network or private data required.
"""
from pathlib import Path
import argparse, hashlib, itertools, json, platform, sys, time
import numpy as np
import pandas as pd
import scipy
from scipy.optimize import linprog, root
from scipy.special import logsumexp
from scipy.stats import poisson, nbinom, t

BASE = Path(__file__).resolve().parents[1]
OUT = BASE / 'results'
OUT.mkdir(exist_ok=True)
MASTER = 20261010
DEMANDS = ('constant', 'poisson', 'negbin')
LAWS = ('A', 'B', 'G', 'E')

def rng_for(*keys):
    return np.random.default_rng(np.random.SeedSequence([MASTER, *keys]))

def maxent(mu, M):
    """Maximum entropy positive-integer pmf with E D=mu, E D^2=2mu^2-mu."""
    d = np.arange(1, M+1, dtype=float)
    x = d / mu
    def moments(theta):
        z = theta[0]*x + theta[1]*x*x
        p = np.exp(z-logsumexp(z))
        return np.array([p @ x - 1, p @ (x*x) - (2-1/mu)])
    sol = root(moments, [mu*np.log1p(-1/mu), 0], tol=1e-11)
    assert np.max(np.abs(moments(sol.x))) < 1e-9, sol.message
    z=sol.x[0]*x+sol.x[1]*x*x
    return d.astype(int), np.exp(z-logsumexp(z))

def pmf(law, mu=4, M=32):
    if law == 'A': return np.array([2,10]), np.array([.75,.25])
    if law == 'B': return np.array([3,16]), np.array([12/13,1/13])
    if law == 'E': return maxent(mu,M)
    if law == 'G':
        d=np.arange(1,1025)
        p=(1/mu)*(1-1/mu)**(d-1)
        return d,p
    raise ValueError(law)

def shortage(S, d, demand):
    """h_S(d)=E[(sum of d independent daily requests - S)+]. Mean daily demand=1."""
    S=np.asarray(S)[...,None]
    d=np.asarray(d,dtype=float)
    if demand=='constant': return np.maximum(d-S,0.)
    if demand=='poisson':
        return np.maximum(d*poisson.sf(S-1,d)-S*poisson.sf(S,d),0.)
    if demand=='negbin':
        r=d/2; p=1/3
        return np.maximum(d*nbinom.sf(S-1,r+1,p)-S*nbinom.sf(S,r,p),0.)
    raise ValueError(demand)

def expected_curve(law, demand, S, mu=4, M=32, availability=.8):
    d,p=pmf(law,mu,M)
    return shortage(S,d,demand) @ p / (mu/(1-availability))

def first_feasible(curve, eps):
    ix=np.flatnonzero(np.asarray(curve)<=eps+1e-12)
    if len(ix)==0: raise ValueError('Stock grid too short')
    return int(ix[0])

def moment_lp(mu, M, h, sense='max'):
    d=np.arange(1,M+1,dtype=float)
    # Scaling prevents unnecessary conditioning loss for large supports.
    A=np.vstack([np.ones(M),d/mu,(d/mu)**2])
    b=np.array([1,1,2-1/mu])
    sign=-1 if sense=='max' else 1
    sol=linprog(sign*np.asarray(h),A_eq=A,b_eq=b,bounds=(0,None),method='highs')
    assert sol.success,sol.message
    resid=float(np.max(np.abs(A@sol.x-b)))
    dualres=float(np.min(sign*h-A.T@sol.eqlin.marginals))
    assert resid < 2e-8 and np.min(sol.x)>-1e-9 and dualres>-2e-8
    assert abs(sol.fun-b@sol.eqlin.marginals)<1e-7
    return float(h@sol.x),sol.x,{'primal_residual':resid,'dual_min_slack':dualres,'duality_gap':abs(sol.fun-b@sol.eqlin.marginals)}

def all_vertices(mu,M):
    """Independent enumeration of all <=3-point distributions for the moment polytope."""
    d=np.arange(1,M+1,dtype=float)
    b=np.array([1,mu,2*mu*mu-mu])
    verts=[]
    for k in (1,2,3):
        for ids in itertools.combinations(range(M),k):
            xx=d[list(ids)]
            A=np.vstack([np.ones(k),xx,xx*xx])
            p=np.linalg.solve(A,b) if k==3 else np.linalg.lstsq(A,b,rcond=None)[0]
            if np.min(p)<-1e-10 or np.max(np.abs(A@p-b))>1e-8: continue
            row=np.zeros(M);row[list(ids)]=np.maximum(p,0)
            verts.append(row)
    return np.unique(np.round(np.array(verts),13),axis=0)

def phase_exact():
    start=time.time();records=[]; moments=[]
    stocks=np.arange(0,81)
    for law in LAWS:
        d,p=pmf(law)
        moments.append(dict(law=law,mass=p.sum(),mean=d@p,second_moment=(d*d)@p,variance=(d*d)@p-(d@p)**2))
        for dm in DEMANDS:
            curve=expected_curve(law,dm,stocks)
            assert np.all(np.diff(curve)<=1e-12)
            assert abs(curve[0]-.2)<1e-10
            for s,v in zip(stocks,curve):records.append(dict(law=law,demand=dm,S=int(s),unmet_fraction=v))
    pd.DataFrame(moments).to_csv(OUT/'moments.csv',index=False)
    curves=pd.DataFrame(records);curves.to_csv(OUT/'exact_curves.csv',index=False)
    choices=[];cross=[]
    for dm in DEMANDS:
        for law in LAWS:
            c=curves[(curves.law==law)&(curves.demand==dm)].unmet_fraction.to_numpy()
            s=first_feasible(c,.01)
            choices.append(dict(law=law,demand=dm,S=s,predicted=c[s]))
            for true in LAWS:
                cross.append(dict(demand=dm,selected_by=law,evaluated_under=true,S=s,actual=expected_curve(true,dm,np.array([s]))[0]))
    pd.DataFrame(choices).to_csv(OUT/'choices.csv',index=False)
    pd.DataFrame(cross).to_csv(OUT/'cross_evaluation.csv',index=False)
    envelope=[];witness=[];checks=[]
    vv=all_vertices(4,32)
    np.savez_compressed(OUT/'main_vertices.npz',pmf=vv,d=np.arange(1,33))
    for dm in DEMANDS:
        hs=shortage(np.arange(0,49),np.arange(1,33),dm)
        for s,h in enumerate(hs):
            lo,pl,cl=moment_lp(4,32,h,'min');hi,ph,ch=moment_lp(4,32,h,'max')
            vals=vv@h
            gap=max(abs(lo-vals.min()),abs(hi-vals.max()))
            assert gap < 1e-8
            envelope.append(dict(demand=dm,S=s,lower=lo/20,upper=hi/20))
            checks.append(dict(demand=dm,S=s,enumeration_gap=gap,**ch))
            for d,p in enumerate(ph,start=1):
                if p>1e-10:witness.append(dict(demand=dm,S=s,d=d,p=p))
    pd.DataFrame(envelope).to_csv(OUT/'main_envelope.csv',index=False)
    pd.DataFrame(witness).to_csv(OUT/'extremal_witnesses.csv',index=False)
    pd.DataFrame(checks).to_csv(OUT/'solver_checks.csv',index=False)
    grid=[]
    for mu,multiple,dm in itertools.product((2,4,6),(4,8,16),DEMANDS):
        M=mu*multiple; ds=np.arange(1,M+1);cache={}
        de,pe=maxent(mu,M); dg,pg=pmf('G',mu,M)
        def cv(s,kind):
            key=(s,kind)
            if key not in cache:
                h=shortage(np.array([s]),ds,dm)[0]
                if kind in ('max','min'):cache[key]=moment_lp(mu,M,h,kind)[0]
                elif kind=='E':cache[key]=h@pe
                elif kind=='G':cache[key]=shortage(np.array([s]),dg,dm)[0]@pg
            return cache[key]
        def bisect(kind,target):
            left,right=0,512
            assert cv(right,kind)<=target
            while left<right:
                mid=(left+right)//2
                if cv(mid,kind)<=target+1e-12:right=mid
                else:left=mid+1
            return left
        for avail,eps in itertools.product((.70,.80,.90,.95),(.005,.01,.02)):
            cycle=mu/(1-avail);target=eps*cycle
            smin=bisect('min',target);smax=bisect('max',target);se=bisect('E',target);sg=bisect('G',target)
            grid.append(dict(mu=mu,M=M,availability=avail,demand=dm,epsilon=eps,S_min=smin,S_maxent=se,S_geometric=sg,S_robust=smax,worst_at_maxent=cv(se,'max')/cycle,worst_at_geometric=cv(sg,'max')/cycle,predicted_maxent=cv(se,'E')/cycle))
    pd.DataFrame(grid).to_csv(OUT/'sensitivity_grid.csv',index=False)
    summary={'vertex_count':len(vv),'max_enumeration_gap':max(x['enumeration_gap'] for x in checks),'grid_cells':len(grid),'exact_runtime_seconds':time.time()-start}
    (OUT/'exact_summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary),flush=True)

def draw_duration(law,rng,n):
    if law=='G':return rng.geometric(.25,size=n)
    d,p=pmf(law)
    return rng.choice(d,size=n,p=p)

def draw_total(d,dm,rng):
    if dm=='constant':return np.array(d,dtype=np.int64)
    if dm=='poisson':return rng.poisson(d)
    return rng.negative_binomial(np.asarray(d)/2,1/3)

def ratio_ci(y,z):
    """Independent cluster totals. Ratio delta method, t critical, untruncated CI."""
    y=np.asarray(y,dtype=float);z=np.asarray(z,dtype=float)
    theta=y.sum(axis=0)/z.sum(axis=0)
    if y.ndim==2 and z.ndim==1:res=y-theta*z[:,None]
    else:res=y-theta*z
    se=np.std(res,axis=0,ddof=1)/(np.sqrt(len(y))*z.mean(axis=0))
    half=t.ppf(.975,len(y)-1)*se
    # A zero observed variance does not establish a zero tail probability.
    # Leave such simulation intervals undefined; exact structural zeros are reported separately.
    lo=np.where(se>0,theta-half,np.nan)
    hi=np.where(se>0,theta+half,np.nan)
    return theta,se,lo,hi

def phase_cycles():
    start=time.time();allrows=[];summary=[];S=np.arange(0,49)
    for li,law in enumerate(LAWS):
        for di,dm in enumerate(DEMANDS):
            rows=[]
            for b in range(200):
                rng=rng_for(200,li,di,b)
                U=rng.geometric(1/16,size=5000);D=draw_duration(law,rng,5000)
                xd=draw_total(D,dm,rng);xu=draw_total(U,dm,rng)
                losses=np.maximum(xd[:,None]-S,0).sum(axis=0)
                den=int((xd+xu).sum())
                for s,y in zip(S,losses):
                    rows.append(dict(law=law,demand=dm,batch=b,S=int(s),unmet=int(y),requests=den,days=int((U+D).sum())))
            frame=pd.DataFrame(rows);allrows.extend(rows)
            for s,g in frame.groupby('S',sort=True):
                est,se,lo,hi=ratio_ci(g.unmet.to_numpy(),g.requests.to_numpy())
                ex=float(expected_curve(law,dm,np.array([s]))[0])
                summary.append(dict(law=law,demand=dm,S=int(s),estimate=float(est),se=float(se),lo=float(lo),hi=float(hi),exact=ex,z=(float(est)-ex)/float(se) if se>0 else np.nan))
    pd.DataFrame(allrows).to_csv(OUT/'cycle_batches.csv.gz',index=False,compression='gzip')
    ss=pd.DataFrame(summary);ss.to_csv(OUT/'cycle_verification.csv',index=False)
    assert np.max(np.abs(ss['z']))<5.5,'Cycle simulator disagreement exceeds diagnostic threshold'
    (OUT/'cycle_summary.json').write_text(json.dumps({'combinations':12,'cycles_per_combination':1000000,'max_abs_z':float(np.max(np.abs(ss['z']))),'runtime_seconds':time.time()-start},indent=2))
    print('Cycle verification complete',flush=True)

def daily_sim(law,dm,horizon,cap,reps,seed_key,stocks):
    """Independent time-step implementation, with pathwise coupling across stock decisions."""
    rng=rng_for(300,*seed_key)
    stocks=np.asarray(stocks)
    inv=np.broadcast_to(stocks,(reps,len(stocks))).copy().astype(np.int64)
    lost=np.zeros_like(inv);total=np.zeros(reps,dtype=np.int64)
    up=np.ones(reps,dtype=bool);rem=rng.geometric(1/16,reps)
    for day in range(horizon):
        switch=(rem==0)
        todown=switch&up;toup=switch&~up
        rem[todown]=draw_duration(law,rng,int(todown.sum()))
        rem[toup]=rng.geometric(1/16,int(toup.sum()))
        up[switch]=~up[switch]
        x=np.ones(reps,dtype=np.int64) if dm=='constant' else rng.poisson(1,reps)
        total+=x
        if cap is None:
            down=~up
            unmet=np.maximum(x[down,None]-inv[down],0)
            lost[down]+=unmet
            inv[down]=np.maximum(inv[down]-x[down,None],0)
            inv[up]=stocks
        else:
            available=inv+(up*cap)[:,None]
            unmet=np.maximum(x[:,None]-available,0)
            lost+=unmet
            inv=np.minimum(stocks,np.maximum(available-x[:,None],0))
        rem-=1
        assert inv.min()>=0 and np.all(inv<=stocks)
    assert np.all(lost<=total[:,None])
    assert np.all(np.diff(lost,axis=1)<=0),'Losses must be pathwise nonincreasing with stock'
    return lost,total

def phase_finite():
    start=time.time();reps=4000;stocks=np.arange(0,33);summary=[]
    raw={}
    for li,law in enumerate(LAWS):
        for di,dm in enumerate(('constant','poisson')):
            for hi,horizon in enumerate((90,365)):
                for ci,cap in enumerate((None,2,4)):
                    # Same seed across capacities: same outage/demand stream.
                    lost,total=daily_sim(law,dm,horizon,cap,reps,(li,di,hi),stocks)
                    theta,se,lo,high=ratio_ci(lost,total)
                    name=f'{law}_{dm}_{horizon}_{cap}'
                    raw[name+'_unmet']=lost.astype(np.int32);raw[name+'_requests']=total.astype(np.int32)
                    for k,s in enumerate(stocks):
                        summary.append(dict(law=law,demand=dm,horizon=horizon,capacity='unlimited' if cap is None else str(cap),S=int(s),estimate=theta[k],se=se[k],lo=lo[k],hi=high[k]))
    np.savez_compressed(OUT/'finite_replications.npz',**raw)
    pd.DataFrame(summary).to_csv(OUT/'finite_horizon.csv',index=False)
    # Long-horizon test of the separately implemented daily model against the renewal formula.
    validation=[]
    for li,law in enumerate(LAWS):
        lost,total=daily_sim(law,'poisson',12000,None,1000,(99,li),np.array([0,5,11,19,32]))
        est,se,lo,hi=ratio_ci(lost,total)
        ex=expected_curve(law,'poisson',np.array([0,5,11,19,32]))
        for k,s in enumerate((0,5,11,19,32)):
            zz=(est[k]-ex[k])/se[k] if se[k]>0 else np.nan
            validation.append(dict(law=law,S=s,estimate=est[k],exact=ex[k],se=se[k],z=zz))
    vf=pd.DataFrame(validation);vf.to_csv(OUT/'independent_daily_validation.csv',index=False)
    assert np.max(np.abs(vf.z))<5.5,'Daily simulator disagreement exceeds diagnostic threshold'
    (OUT/'finite_summary.json').write_text(json.dumps({'scenario_cells':48,'replications_per_cell':reps,'max_daily_validation_z':float(np.max(np.abs(vf.z))),'runtime_seconds':time.time()-start},indent=2))
    print('Finite-horizon simulations complete',flush=True)

def save_environment():
    env={'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'pandas':pd.__version__,'platform':platform.platform(),'master_seed':MASTER,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'protocol_sha256':hashlib.sha256((BASE/'PROTOCOL.md').read_bytes()).hexdigest()}
    (OUT/'environment.json').write_text(json.dumps(env,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--phase',choices=['exact','cycles','finite','all'],default='all');a=parser.parse_args()
    save_environment()
    for name,fn in [('exact',phase_exact),('cycles',phase_cycles),('finite',phase_finite)]:
        if a.phase in ('all',name):fn()
