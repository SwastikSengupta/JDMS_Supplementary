"""Independent mathematical and numerical checks, plus finite-trace counterexample."""
from pathlib import Path
from fractions import Fraction
import hashlib, json
import numpy as np
import pandas as pd
from scipy.stats import poisson, nbinom
from study import BASE, OUT, shortage, ratio_ci, pmf, expected_curve

checks=[]
def check(name,condition,detail):
    assert bool(condition),(name,detail)
    checks.append(dict(check=name,status='passed',detail=detail))

# Exact rational moment identities independent of the numerical fitting code.
for law,ds,ps in [('A',[2,10],[Fraction(3,4),Fraction(1,4)]),('B',[3,16],[Fraction(12,13),Fraction(1,13)])]:
    check(law+' rational moments',sum(p*d for p,d in zip(ps,ds))==4 and sum(p*d*d for p,d in zip(ps,ds))==28,'Mean 4 and second moment 28 exactly')

# Direct pmf summation independently checks the survival-function shortcut for random demand.
errs=[]
for dm in ('poisson','negbin'):
    for d in (1,4,16):
        k=np.arange(0,1000)
        pp=poisson.pmf(k,d) if dm=='poisson' else nbinom.pmf(k,d/2,1/3)
        for S in (0,5,11,24):
            brute=np.maximum(k-S,0)@pp
            closed=shortage(np.array([S]),np.array([d]),dm)[0,0]
            errs.append(abs(brute-closed))
check('Random demand loss formula',max(errs)<1e-10,f'Maximum direct-sum discrepancy {max(errs):.3g}')

# Finite circular traces: all first-order counts and first two outage moments match exactly.
# The shared normal-spell length is 16; this witness is separate from the geometric-U experiment.
traces={};trace_stats=[]
for law,D in [('A',np.array([2]*39+[10]*13)),('B',np.array([3]*48+[16]*4))]:
    rng=np.random.default_rng(919);rng.shuffle(D)
    trace=np.concatenate([np.r_[np.ones(16,dtype=int),np.zeros(d,dtype=int)] for d in D])
    nxt=np.roll(trace,-1)
    counts=[int(((trace==a)&(nxt==b)).sum()) for a,b in ((0,0),(0,1),(1,0),(1,1))]
    losses={S:int(np.maximum(D-S,0).sum()) for S in (10,11,14)}
    trace_stats.append(dict(law=law,days=len(trace),normal_days=int(trace.sum()),outages=len(D),mean_outage=D.mean(),second_outage=(D**2).mean(),N00=counts[0],N01=counts[1],N10=counts[2],N11=counts[3],**{f'unmet_S{S}':n for S,n in losses.items()}))
    traces[law]=trace
pd.DataFrame(trace_stats).to_csv(OUT/'finite_trace_witness.csv',index=False)
pd.DataFrame(traces).to_csv(OUT/'finite_trace_states.csv',index=False)
check('Identical finite-trace diagnostics',all(trace_stats[0][k]==trace_stats[1][k] for k in ('days','normal_days','outages','mean_outage','second_outage','N00','N01','N10','N11')),'52 outages in 1040-day circular traces; 80 percent availability')

# Correct old stored diagnostics without resimulating unchanged paths.
for fn in ('cycle_verification.csv','finite_horizon.csv','independent_daily_validation.csv'):
    f=pd.read_csv(OUT/fn);zero=(f.se==0)
    for col in ('z','lo','hi'):
        if col in f:f.loc[zero,col]=np.nan
    f['interval_status']=np.where(zero,'no_sampling_interval','estimated')
    f.to_csv(OUT/fn,index=False)

# Paired differences have identical demand and outage draws across capacities.
raw=np.load(OUT/'finite_replications.npz');pr=[]
for law in ('A','B','G','E'):
    for dm in ('constant','poisson'):
        for horizon in (90,365):
            key=f'{law}_{dm}_{horizon}_None'
            y0=raw[key+'_unmet'];z0=raw[key+'_requests']
            for cap in (2,4):
                alt=f'{law}_{dm}_{horizon}_{cap}';y1=raw[alt+'_unmet'];z1=raw[alt+'_requests']
                check(f'Coupled paths {law} {dm} {horizon} {cap}',np.array_equal(z0,z1),'Demand totals agree across replenishment capacities')
                est,se,lo,hi=ratio_ci(y1-y0,z0)
                for s in range(33):pr.append(dict(law=law,demand=dm,horizon=horizon,capacity=cap,S=s,additional_unmet=est[s],se=se[s],lo=lo[s],hi=hi[s]))
pd.DataFrame(pr).to_csv(OUT/'paired_capacity_effects.csv',index=False)

v=pd.read_csv(OUT/'solver_checks.csv')
check('LP and independent enumeration',v.enumeration_gap.max()<1e-8,f'147 lower and 147 upper bounds; max discrepancy {v.enumeration_gap.max():.3g} requests/cycle')
c=pd.read_csv(OUT/'cycle_verification.csv')
check('Complete-cycle Monte Carlo check',c.z.abs().max()<5.5,f'Max finite standardized error {c.z.abs().max():.3f}; zero-variance estimates excluded')
d=pd.read_csv(OUT/'independent_daily_validation.csv')
check('Independent daily simulation check',d.z.abs().max()<5.5,f'Max finite standardized error {d.z.abs().max():.3f}; finite-start initialization retained')

(OUT/'verification_report.json').write_text(json.dumps({'checks':checks,'all_passed':True,'note':'Numerical and code verification only; no empirical military validation.'},indent=2))
print(f'{len(checks)} verification checks passed')
