"""Typeset the manuscript with the unmodified Sage journal class.

The title/header definitions omit publisher-only production metadata. The
document is an author manuscript, not a facsimile of an accepted journal proof.
Requires Pandoc, pdfLaTeX, and the class retained under vendor/.
"""
from pathlib import Path
import re, subprocess, shutil, json

BASE=Path(__file__).resolve().parents[1]
BUILD=BASE/'build'/'publication'
BUILD.mkdir(parents=True,exist_ok=True)

def latex(md):
    return subprocess.run(['pandoc','-f','markdown-implicit_figures','-t','latex',
        '--shift-heading-level-by=-1','--wrap=none'],input=md,text=True,
        capture_output=True,check=True).stdout.strip()

src=(BASE/'docs/manuscript.md').read_text()
title=re.search(r'^title: (.+)$',src,re.M).group(1)
abstract=src.split('## Abstract\n\n')[1].split('\n\n**Keywords:')[0]
keywords=re.search(r'\*\*Keywords:\*\* (.+)',src).group(1)
body='## 1 Introduction'+src.split('## 1 Introduction',1)[1]
body,refs=body.split('\n\n## References\n\n')

def raw(tex):return '\n\n```{=latex}\n'+tex+'\n```\n\n'

def table(m):
    cap=m.group(1);lines=m.group(2).strip().splitlines()
    rows=[[c.strip() for c in row.strip().strip('|').split('|')] for row in lines]
    rows=rows[:1]+rows[2:]
    n=len(rows[0]);number=int(m.group(3)) if m.lastindex and m.lastindex>=3 else 0
    if n==2:spec=r'>{\hsize=.8\hsize\raggedright\arraybackslash}X>{\hsize=1.2\hsize\raggedright\arraybackslash}X'
    elif n==3:spec=r'>{\hsize=.7\hsize\raggedright\arraybackslash}X>{\hsize=1.6\hsize\raggedright\arraybackslash}X>{\hsize=.7\hsize\raggedright\arraybackslash}X'
    else:spec=r'>{\hsize=.55\hsize\raggedright\arraybackslash}X'+r'>{\hsize=1.15\hsize\raggedright\arraybackslash}X'*3
    # The literature table benefits from equal-width explanatory columns.
    if cap.startswith('Relation to'):spec=r'>{\hsize=.8\hsize\raggedright\arraybackslash}X'+r'>{\hsize=1.1\hsize\raggedright\arraybackslash}X'*2
    rendered=[]
    for i,row in enumerate(rows):
        cells=[latex(c) for c in row]
        if i==0:cells=[r'\textbf{'+c+'}' for c in cells]
        rendered.append(' & '.join(cells)+r' \\'+('\n\\midrule' if i==0 else ''))
    return raw(r'\begin{table*}[t]'+'\n'+r'\caption{'+latex(cap)+'}\n'+
        r'\small\sffamily\renewcommand{\arraystretch}{1.18}'+'\n'+
        r'\begin{tabularx}{\textwidth}{@{}'+spec+r'@{}}\toprule'+'\n'+
        '\n'.join(rendered)+'\n'+r'\bottomrule\end{tabularx}\end{table*}')

body=re.sub(r'\*\*Table \d+\. (.+)\*\*\n\n((?:\|[^\n]+\n)+)',table,body)

def figure(m):
    path=m.group(1);cap=m.group(2)+m.group(3)
    absolute=(BASE/'docs'/path).resolve()
    return raw(r'\begin{figure*}[t]\centering'+'\n'+
        r'\includegraphics[width=.94\textwidth]{'+str(absolute)+'}\n'+
        r'\caption{'+latex(cap)+r'}\end{figure*}')

body=re.sub(r'!\[[^\n]*\]\(([^)]+)\)\{[^\n]*\}\n\n\*\*Figure \d+\. (.+?)\*\*(.*)',figure,body)

eqs=[
r'\begin{equation}\begin{aligned}h_S(d)&=\mathrm{E}[(X_d-S)^+],\\L(S)&=\frac{\mathrm{E}[h_S(D)]}{\lambda\,\mathrm{E}[U+D]}.\end{aligned}\tag{1}\end{equation}',
r'\begin{equation}S^*(\epsilon)=\min\{S\in\mathbb{Z}_{\geq0}:L(S)\leq\epsilon\}.\tag{2}\end{equation}',
r'\begin{equation}\begin{aligned}A&=\frac{\mathrm{E}[U]}{\mathrm{E}[U]+\mathrm{E}[D]},\\p_{10}&=\frac{1}{\mathrm{E}[U]},\qquad p_{01}=\frac{1}{\mathrm{E}[D]}.\end{aligned}\tag{3}\end{equation}',
r'\begin{equation}\begin{aligned}v&=\frac{\mathrm{Var}[(1-A)U-AD]}{\mathrm{E}[U+D]}=0.864,\\T\,\mathrm{Var}(\widehat A_T)&\longrightarrow v.\end{aligned}\tag{4}\end{equation}',
r'\noindent\begin{minipage}{\columnwidth}\[\min_q\sum_{d=1}^{M}q_d h_S(d)\quad\mathrm{or}\quad\max_q\sum_{d=1}^{M}q_d h_S(d)\]',
r'\begin{equation}\begin{aligned}\sum_{d=1}^{M}q_d&=1,&\sum_{d=1}^{M}d q_d&=\mu,\\\sum_{d=1}^{M}d^2q_d&=m_2,&q_d&\geq0.\end{aligned}\tag{5}\end{equation}\end{minipage}\par\vspace{6pt}',
r'\begin{equation}\begin{aligned}P_S(d)&=\frac{(d-3)(d-4)}{4S-14},\\P_S(d)-(d-S)&=\frac{(d-(2S-4))(d-(2S-3))}{4S-14}.\end{aligned}\tag{6}\end{equation}',
r'\begin{equation}L_+^{\infty}(S)=\frac{3}{10(2S-7)},\quad S\in\mathbb{Z},\ S\geq10.\tag{7}\end{equation}',
r'\begin{equation}\mathrm{E}[(D-S)^+]=\sum_{k=S+1}^{\infty}\Pr(D\geq k).\tag{8}\end{equation}',
r'\begin{equation}\begin{aligned}\widehat L&=\frac{\sum_bY_b}{\sum_bZ_b},\\\operatorname{SE}(\widehat L)&=\frac{s(Y_b-\widehat L Z_b)}{\sqrt{B}\,\overline Z}.\end{aligned}\tag{9}\end{equation}'
]
counter=iter(eqs)
body,count=re.subn(r'\$\$(.*?)\$\$',lambda m:raw(next(counter)),body,flags=re.S)
assert count==len(eqs),count

body=latex(body)
intro=latex('The reserve choice at loss limit $\\epsilon$ is')
body=body.replace(intro, r'\noindent\begin{minipage}{\columnwidth}'+intro)
body=body.replace(r'\tag{2}\end{equation}',r'\tag{2}\end{equation}\end{minipage}\par\vspace{6pt}')
# Keep body numbering explicit, as in the editable manuscript.
body=re.sub(r'(\\section\{)([1-9]) ',r'\g<1>\2. ',body)
# All floats should be read before the back matter starts.
body=body.replace(r'\section{Acknowledgements}',r'\FloatBarrier\small\compactbackmatter'+ '\n'+r'\section{Acknowledgements}')

reference_latex=[]
for item in re.split(r'\n\n',refs.strip()):
    m=re.match(r'(\d+)\\\. (.+)',item,re.S)
    if not m:raise ValueError(item)
    i,text=m.groups()
    reference_latex.append(r'\bibitem{ref'+i+'} '+latex(text))

preamble=r'''\documentclass[shortAfour,sagev,times]{sagej}
\geometry{papersize={216mm,280mm},text={171mm,229mm},columnsep=5mm,headsep=7mm}
\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage{tabularx,array,microtype,placeins,url,balance}
\usepackage[hidelinks]{hyperref}
\urlstyle{same}
\setlength{\emergencystretch}{1em}
\setlength{\dbltextfloatsep}{14pt plus 2pt minus 2pt}
\setlength{\textfloatsep}{12pt plus 2pt minus 2pt}
\setlength{\intextsep}{12pt plus 2pt minus 2pt}
\raggedbottom
\predisplaypenalty=10000
\providecommand{\tightlist}{\setlength{\itemsep}{0pt}\setlength{\parskip}{0pt}}
\makeatletter
\def\@maketitle{%
  \vspace*{-20pt}\noindent{\sffamily\small Research Article}\par
  \vspace{5pt}\hrule height .5pt\vspace{15pt}
  {\sffamily\titlesize\bfseries\raggedright\@title\par}
  \vspace{18pt}{\sffamily\large\bfseries\@author\par}
  \vspace{18pt}\noindent\usebox\absbox\par
  \vspace{14pt}{\sffamily\@keywords\par}\vspace{22pt}}
\def\ps@title{\def\@oddhead{}\let\@evenhead\@oddhead
 \def\@oddfoot{}\let\@evenfoot\@oddfoot}
\def\ps@sagepage{%
 \def\@oddhead{\sffamily\small Sengupta\hfill\thepage}
 \def\@evenhead{\sffamily\small\thepage\hfill Reserve requirements under matched outage statistics}
 \def\@oddfoot{}\let\@evenfoot\@oddfoot}
\newcommand{\compactbackmatter}{%
 \renewcommand\section{\@startsection{section}{1}{\z@}{10pt}{4pt}{\sffamily\normalsize\bfseries\raggedright}}%
 \renewcommand\subsection{\@startsection{subsection}{2}{\z@}{7pt}{3pt}{\sffamily\small\bfseries\raggedright}}}
\makeatother
\pagestyle{sagepage}
\hypersetup{pdftitle={Matching outage statistics does not identify reserve requirements in a defense support model},pdfauthor={Swastik Sengupta},pdfsubject={Author manuscript prepared for JDMS}}
'''

front=r'\title{'+latex(title)+'}\n'+r'\author{Swastik Sengupta\\[3pt]{\small ORCID: \href{https://orcid.org/0009-0002-9414-7443}{0009-0002-9414-7443}}}'+'\n'+r'''\affiliation{Las Positas College, Livermore, California, USA}
\corrauth{Swastik Sengupta, Las Positas College, Livermore, California, USA.}
\email{swastik.sngpta@gmail.com}
\begin{document}
\begin{abstract}
'''+latex(abstract)+'\n'+r'\end{abstract}'+'\n'+r'\keywords{'+latex(keywords)+'}\n'+r'\maketitle'+'\n'

tex=preamble+front+body+'\n'+r'\clearpage\balance\begin{thebibliography}{99}'+'\n'+'\n'.join(reference_latex)+'\n'+r'\end{thebibliography}'+'\n'+r'\end{document}'+'\n'
(BUILD/'manuscript.tex').write_text(tex)
shutil.copyfile(BASE/'vendor'/'sagej.cls',BUILD/'sagej.cls')
# Keep a portable, editable LaTeX source beside the Markdown and bibliography.
portable=tex.replace(str((BASE/'figures').resolve())+'/', '../figures/')
(BASE/'docs'/'manuscript.tex').write_text(portable)
shutil.copyfile(BASE/'vendor'/'sagej.cls',BASE/'docs'/'sagej.cls')
for _ in range(2):
    p=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error','manuscript.tex'],cwd=BUILD,capture_output=True,text=True)
    (BUILD/'compile_stdout.txt').write_text(p.stdout)
    if p.returncode:raise RuntimeError(p.stdout[-6000:])
dest=BASE/'deliverables'/'JDMS_Resupply_Manuscript.pdf'
dest.parent.mkdir(parents=True,exist_ok=True)
shutil.copyfile(BUILD/'manuscript.pdf',dest)
print(dest)
print('\n'.join(line for line in (BUILD/'manuscript.log').read_text().splitlines() if 'Overfull' in line or 'Output written' in line))
