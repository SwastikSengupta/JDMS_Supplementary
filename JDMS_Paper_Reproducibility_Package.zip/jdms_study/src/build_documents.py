"""Create editable journal manuscript and companion review documents.

Requires Pandoc and python-docx. PDF rendering is a separate operation.
"""
from pathlib import Path
import argparse, json, re, subprocess
from copy import deepcopy
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

BASE=Path(__file__).resolve().parents[1]

def reference_document(path):
    doc=Document()
    sec=doc.sections[0]
    sec.page_width=Inches(8.5);sec.page_height=Inches(11)
    sec.top_margin=sec.bottom_margin=Inches(.8)
    sec.left_margin=sec.right_margin=Inches(1)
    sec.header_distance=sec.footer_distance=Inches(.35)
    for sty in doc.styles:
        if sty.type==1:
            sty.font.name='Times New Roman';sty.font.size=Pt(12)
            sty.font.color.rgb=RGBColor(0,0,0)
    s=doc.styles['Normal'];s.paragraph_format.space_after=Pt(6)
    s.paragraph_format.line_spacing=1.06
    for name in ('Body Text','First Paragraph'):
        if name in doc.styles:
            doc.styles[name].base_style=s
            doc.styles[name].paragraph_format.space_after=Pt(6)
            doc.styles[name].paragraph_format.line_spacing=1.06
    for n in ('Title','Subtitle','Author','Date'):
        if n in doc.styles:
            st=doc.styles[n];st.font.color.rgb=RGBColor(0,0,0)
            st.paragraph_format.space_after=Pt(8)
    doc.styles['Title'].font.size=Pt(18);doc.styles['Title'].font.bold=True
    doc.styles['Title'].paragraph_format.line_spacing=1.04
    for n,size in [('Heading 1',14),('Heading 2',12),('Heading 3',12)]:
        st=doc.styles[n];st.font.size=Pt(size);st.font.bold=True
        st.paragraph_format.space_before=Pt(12);st.paragraph_format.space_after=Pt(5)
        st.paragraph_format.keep_with_next=True
    for name in ('Caption','Image Caption','Table Caption'):
        if name in doc.styles:
            st=doc.styles[name];st.font.size=Pt(11);st.font.italic=False
    doc.save(path)

def insert_field(p,name):
    r=p.add_run();f=OxmlElement('w:fldSimple');f.set(qn('w:instr'),name);r._r.addnext(f)

def polish(path,main):
    doc=Document(path)
    # Rebuild table paragraphs: the renderer mishandles Pandoc's Compact
    # paragraph style in cells. Keep editable runs/math in fresh normal cells.
    for old in list(doc.tables):
        new=doc.add_table(rows=len(old.rows),cols=len(old.columns))
        new.style='Table Grid'
        for ro,rn in zip(old.rows,new.rows):
            for co,cn in zip(ro.cells,rn.cells):
                for i,po in enumerate(co.paragraphs):
                    pn=cn.paragraphs[0] if i==0 else cn.add_paragraph()
                    for child in po._p:
                        if child.tag!=qn('w:pPr'):pn._p.append(deepcopy(child))
        old._tbl.addprevious(new._tbl)
        old._tbl.getparent().remove(old._tbl)
    for st in doc.styles:
        if st.type in (1,2):
            st.font.name='Times New Roman';st.font.color.rgb=RGBColor(0,0,0)
            if st.element.rPr is not None and st.element.rPr.rFonts is not None:
                for k in ('asciiTheme','hAnsiTheme','eastAsiaTheme','cstheme'):
                    st.element.rPr.rFonts.attrib.pop(qn('w:'+k),None)
        for b in st.element.findall('.//'+qn('w:pBdr')):b.getparent().remove(b)
    for sec in doc.sections:
        sec.page_width=Inches(8.5);sec.page_height=Inches(11)
        sec.top_margin=sec.bottom_margin=Inches(.8)
        sec.left_margin=sec.right_margin=Inches(1)
        sec.header_distance=sec.footer_distance=Inches(.35)
        hp=sec.header.paragraphs[0]
        hp.text='Sengupta | Reserve requirements under matched outage statistics' if main else 'JDMS manuscript revision | 11 October 2026'
        for r in hp.runs:r.font.name='Times New Roman';r.font.size=Pt(9);r.font.color.rgb=RGBColor.from_string('555555')
        fp=sec.footer.paragraphs[0];fp.alignment=WD_ALIGN_PARAGRAPH.CENTER
        insert_field(fp,'PAGE')
        for r in fp.runs:r.font.size=Pt(9)
    inrefs=False
    for p in doc.paragraphs:
        text=p.text.strip()
        for b in p._p.findall('.//'+qn('w:pBdr')):b.getparent().remove(b)
        p.paragraph_format.widow_control=True
        if text=='1 Introduction' and main:p.paragraph_format.page_break_before=True
        if main and text=='4.4 What the audit asks an analyst to retain':
            p.paragraph_format.page_break_before=True
        if main and text in ('Tables','Figures'):
            p.paragraph_format.page_break_before=True
            inrefs=False
        if text=='References':inrefs=True
        elif inrefs and text:
            p.paragraph_format.left_indent=Inches(.22)
            p.paragraph_format.first_line_indent=Inches(-.22)
            p.paragraph_format.space_after=Pt(5)
            for r in p.runs:r.font.size=Pt(10.5)
        if text.startswith(('Figure ','Table ')):
            p.paragraph_format.space_after=Pt(7)
            for r in p.runs:r.font.size=Pt(11)
            if text.startswith('Table '):
                p.paragraph_format.keep_with_next=True
                p.paragraph_format.space_before=Pt(10)
                if main and text.startswith('Table 3.'):
                    p.paragraph_format.page_break_before=True
        if p._p.findall('.//'+qn('w:drawing')):
            p.paragraph_format.keep_with_next=True
            p.paragraph_format.space_before=Pt(7);p.paragraph_format.space_after=Pt(3)
            p.alignment=WD_ALIGN_PARAGRAPH.CENTER
            if main and p._p.getprevious() is not None:
                previous=''.join(p._p.getprevious().itertext())
                if 'Figures' not in previous:p.paragraph_format.page_break_before=True
        if p._p.findall('.//{http://schemas.openxmlformats.org/officeDocument/2006/math}oMathPara'):
            p.paragraph_format.space_before=Pt(5);p.paragraph_format.space_after=Pt(7)
            p.paragraph_format.keep_together=True
            previous=p._p.getprevious()
            if previous is not None and previous.tag==qn('w:p'):
                pp=previous.get_or_add_pPr()
                for old_keep in pp.findall(qn('w:keepNext')):
                    pp.remove(old_keep)
                pp.get_or_add_keepNext().val=True
    for table in doc.tables:
        table.autofit=False
        n=len(table.columns)
        widths=[6.5/n]*n
        if n==2:widths=[2.25,4.25]
        if n==3:widths=[1.6,2.5,2.4]
        if n==4:widths=[.75,1.75,1.75,2.25]
        for col,w in zip(table.columns,widths):col.width=Inches(w)
        for i,row in enumerate(table.rows):
            trPr=row._tr.get_or_add_trPr()
            cant=OxmlElement('w:cantSplit');trPr.append(cant)
            if i==0:
                repeat=OxmlElement('w:tblHeader');trPr.append(repeat)
            for j,cell in enumerate(row.cells):
                cell.width=Inches(widths[j])
                tcPr=cell._tc.get_or_add_tcPr()
                borders=OxmlElement('w:tcBorders')
                for side in ('top','bottom','left','right'):
                    e=OxmlElement('w:'+side)
                    visible=side=='bottom' and (i==0 or i==len(table.rows)-1) or side=='top' and i==0
                    e.set(qn('w:val'),'single' if visible else 'nil');e.set(qn('w:sz'),'6');e.set(qn('w:color'),'000000');borders.append(e)
                tcPr.append(borders)
                margins=OxmlElement('w:tcMar')
                for side in ('top','bottom','left','right'):
                    m=OxmlElement('w:'+side);m.set(qn('w:w'),'80');m.set(qn('w:type'),'dxa');margins.append(m)
                tcPr.append(margins)
                for p in cell.paragraphs:
                    p.paragraph_format.space_after=Pt(2);p.paragraph_format.line_spacing=1.03
                    p.paragraph_format.keep_with_next=False
                    for r in p.runs:
                        r.font.name='Times New Roman';r.font.size=Pt(10.5)
                        if i==0:r.bold=True
    # Use an installed OpenType math font while preserving native Office Math.
    math_ns='http://schemas.openxmlformats.org/officeDocument/2006/math'
    math_pr=doc.settings.element.find('{'+math_ns+'}mathPr')
    if math_pr is None:
        math_pr=OxmlElement('m:mathPr');doc.settings.element.append(math_pr)
    math_font=math_pr.find('{'+math_ns+'}mathFont')
    if math_font is None:
        math_font=OxmlElement('m:mathFont');math_pr.append(math_font)
    math_font.set(qn('m:val'),'Latin Modern Math')
    for math_run in doc.element.findall('.//{'+math_ns+'}r'):
        rpr=math_run.find(qn('w:rPr'))
        if rpr is None:
            rpr=OxmlElement('w:rPr')
            mrpr=math_run.find('{'+math_ns+'}rPr')
            if mrpr is None:math_run.insert(0,rpr)
            else:mrpr.addnext(rpr)
        fonts=rpr.find(qn('w:rFonts'))
        if fonts is None:
            fonts=OxmlElement('w:rFonts');rpr.insert(0,fonts)
        for name in ('ascii','hAnsi','eastAsia','cs'):
            fonts.set(qn('w:'+name),'Latin Modern Math')
    # Plain math delimiter runs avoid a stretched-glyph rendering defect in
    # office renderers while retaining editable expressions and their meaning.
    for delimiter in reversed(doc.element.findall('.//{'+math_ns+'}d')):
        props=delimiter.find('{'+math_ns+'}dPr')
        def delimiter_char(name,default):
            item=props.find('{'+math_ns+'}'+name) if props is not None else None
            return item.get(qn('m:val'),default) if item is not None else default
        begin=delimiter_char('begChr','(');end=delimiter_char('endChr',')')
        sep=delimiter_char('sepChr','|')
        def math_text(value):
            run=OxmlElement('m:r');pr=OxmlElement('m:rPr')
            sty=OxmlElement('m:sty');sty.set(qn('m:val'),'p');pr.append(sty);run.append(pr)
            t=OxmlElement('m:t');t.text=value;run.append(t);return run
        if begin:delimiter.addprevious(math_text(begin))
        for idx,arg in enumerate(delimiter.findall('{'+math_ns+'}e')):
            if idx and sep:delimiter.addprevious(math_text(sep))
            for child in list(arg):delimiter.addprevious(child)
        if end:delimiter.addprevious(math_text(end))
        delimiter.getparent().remove(delimiter)
    doc.save(path)

def submission_order(src):
    """Put editable tables and captioned figures after text and references."""
    tables=[];figures=[]
    def table(m):tables.append(m.group(0));return ''
    def figure(m):figures.append(m.group(0));return ''
    src=re.sub(r'\*\*Table \d+\.[^\n]+\*\*\n\n(?:\|[^\n]+\n)+',table,src)
    src=re.sub(r'!\[[^\n]+\n\n\*\*Figure \d+\.[^\n]+',figure,src)
    assert len(tables)==4 and len(figures)==5
    return src+'\n\n## Tables\n\n'+'\n\n'.join(tables)+'\n\n## Figures\n\n'+'\n\n'.join(figures)+'\n'

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',default=str(BASE/'deliverables'));a=p.parse_args()
    out=Path(a.output).resolve();out.mkdir(exist_ok=True,parents=True)
    build=BASE/'build';build.mkdir(exist_ok=True)
    ref=build/'reference.docx';reference_document(ref)
    refs=json.loads((BASE/'docs/references.json').read_text())
    src=(BASE/'docs/manuscript_source.md').read_text()
    order=[]
    def citation(m):
        keys=[s.strip().lstrip('@') for s in m.group(1).split(';')]
        for k in keys:
            assert k in refs,k
            if k not in order:order.append(k)
        return '^'+','.join(str(order.index(k)+1) for k in keys)+'^'
    src=re.sub(r'\[(@[^\]]+)\]',citation,src)
    bibliography='\n\n'.join(str(i)+r'\. '+refs[k] for i,k in enumerate(order,1))
    src=src.replace('{{REFERENCES}}',bibliography)
    generated=BASE/'docs/manuscript.md';generated.write_text(src)
    (BASE/'docs/citation_order.json').write_text(json.dumps(order,indent=2))
    submission=BASE/'docs/manuscript_submission.md';submission.write_text(submission_order(src))
    jobs=[(submission,out/'JDMS_Resupply_Manuscript.docx',True),
          (BASE/'docs/journal_strategy.md',build/'JDMS_Research_Strategy.docx',False)]
    for md,dest,is_main in jobs:
        subprocess.run(['pandoc',str(md),'-f','markdown-implicit_figures','--reference-doc',str(ref),'-o',str(dest)],cwd=BASE/'docs',check=True)
        polish(dest,is_main)
        print(dest)
    import zipfile
    from lxml import etree
    with zipfile.ZipFile(jobs[0][1]) as z:
        root=etree.fromstring(z.read('word/document.xml'))
        ns={'m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
        eq=len(root.xpath('//m:oMath',namespaces=ns))
    print(f'Editable Office Math objects: {eq}; references: {len(order)}')

if __name__=='__main__':main()
