from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter, MaxNLocator
from study import BASE, OUT, pmf

F=BASE/'figures';F.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.titlesize':10,'axes.labelsize':9,'legend.fontsize':8,'xtick.labelsize':8,'ytick.labelsize':8,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.6,'grid.alpha':.2,'svg.fonttype':'none','savefig.dpi':360})
C={'A':'#176A78','B':'#AD4A21','G':'#303F69','E':'#776497'}
L={'A':'A  Two or ten days','B':'B  Three or sixteen days','G':'G  Geometric','E':'E  Maximum entropy'}
def save(fig,name):
    fig.savefig(F/(name+'.png'),bbox_inches='tight',dpi=360)
    fig.savefig(F/(name+'.svg'),bbox_inches='tight')
    plt.close(fig)

fig,ax=plt.subplots(2,2,figsize=(6.45,3.6),layout='constrained',sharex=True,sharey=True)
for a,law in zip(ax.flat,('A','B','G','E')):
    d,p=pmf(law);mask=d<=32
    a.bar(d[mask],p[mask],color=C[law],width=.75)
    a.set_title(L[law],loc='left',fontweight='bold');a.set_xlim(0,33);a.set_ylim(0,1)
    a.set_xticks([1,8,16,24,32]);a.grid(axis='y')
for a in ax[1]:a.set_xlabel('Outage length (days)')
for a in ax[:,0]:a.set_ylabel('Probability')
save(fig,'figure1_outage_laws')

c=pd.read_csv(OUT/'exact_curves.csv');chs=pd.read_csv(OUT/'choices.csv')
fig,ax=plt.subplots(1,2,figsize=(6.45,3.25),layout='constrained',sharey=True)
for a,dm,title in zip(ax,('constant','poisson'),('One request each day','Poisson requests')):
    for law in ('A','B','G','E'):
        s=c[(c.demand==dm)&(c.law==law)&(c.S<=24)]
        a.plot(s.S,s.unmet_fraction*100,label=law,color=C[law],lw=1.65,ls={'A':'-','B':'-','G':'--','E':':'}[law])
        ch=chs[(chs.demand==dm)&(chs.law==law)].iloc[0]
        a.scatter(ch.S,ch.predicted*100,color=C[law],s=20,zorder=4,marker={'A':'o','B':'s','G':'^','E':'D'}[law])
    a.axhline(1,color='#111111',lw=.9,ls='--');a.set_xlim(4,22);a.set_ylim(0,7.5)
    a.set_title(title,loc='left',fontweight='bold');a.set_xlabel('Reserve stock (units)');a.grid(axis='y')
    a.xaxis.set_major_locator(MaxNLocator(integer=True));a.legend(ncol=2,frameon=False,loc='upper right')
ax[0].set_ylabel('Unmet requests (%)')
save(fig,'figure2_reserve_decisions')

e=pd.read_csv(OUT/'main_envelope.csv');ee=e[(e.demand=='constant')&(e.S<=24)]
fig,ax=plt.subplots(figsize=(6.45,3.4),layout='constrained')
ax.fill_between(ee.S,100*ee.lower,100*ee.upper,color='#DCE9EB',label='All bounded laws with the same moments')
ax.plot(ee.S,100*ee.upper,color='#176A78',lw=1.7,label='Tight upper bound')
for law,sty in [('B','-'),('E','--')]:
    cc=c[(c.demand=='constant')&(c.law==law)&(c.S<=24)]
    ax.plot(cc.S,100*cc.unmet_fraction,color=C[law],ls=sty,lw=1.5,label=L[law])
ax.axhline(1,color='#111111',ls='--',lw=.9,label='1% requirement')
ax.scatter([11,19],[2,.960591133],color='#176A78',s=25,zorder=5)
ax.annotate('11 units can leave 2% unmet',xy=(11,2),xytext=(11.4,3.45),arrowprops={'arrowstyle':'-','color':'#444','lw':.7},fontsize=8.5)
ax.annotate('19 units meet the bound',xy=(19,.960591133),xytext=(15.6,2.6),arrowprops={'arrowstyle':'-','color':'#444','lw':.7},fontsize=8.5)
ax.set_xlim(4,24);ax.set_ylim(0,7);ax.set_xlabel('Reserve stock (units)');ax.set_ylabel('Unmet requests (%)');ax.grid(axis='y')
ax.legend(loc='upper right',frameon=False,fontsize=7.6)
save(fig,'figure3_identified_bounds')

g=pd.read_csv(OUT/'sensitivity_grid.csv')
fig,axs=plt.subplots(1,3,figsize=(6.45,3.1),layout='constrained',sharex=True,sharey=True)
for ax,dm,title in zip(axs,('constant','poisson','negbin'),('Constant demand','Poisson demand','Overdispersed demand')):
    gg=g[g.demand==dm]
    for eps,mark,col in [(.005,'o','#176A78'),(.01,'s','#AD4A21'),(.02,'^','#776497')]:
        h=gg[gg.epsilon==eps]
        ax.scatter(h.S_maxent,h.S_robust,s=17,alpha=.75,marker=mark,color=col,label=f'{100*eps:g}% target')
    ax.plot([0,80],[0,80],ls='--',lw=.8,color='#555');ax.set_xlim(0,58);ax.set_ylim(0,84)
    ax.set_title(title,loc='left',fontsize=9,fontweight='bold');ax.set_xlabel('Maximum entropy stock');ax.grid()
axs[0].set_ylabel('Stock covering all matched laws')
axs[2].legend(loc='upper left',frameon=False,fontsize=7)
save(fig,'figure4_sensitivity')

f=pd.read_csv(OUT/'finite_horizon.csv')
fig,axs=plt.subplots(1,2,figsize=(6.45,3.4),layout='constrained',sharey=True)
for ax,dm,ss,title in zip(axs,('constant','poisson'),(11,12),('One request daily   S = 11','Poisson requests   S = 12')):
    for i,law in enumerate(('A','B','G','E')):
        gg=f[(f.law==law)&(f.demand==dm)&(f.horizon==365)&(f.S==ss)]
        gg=gg.set_index('capacity').loc[['unlimited','4','2']]
        ax.errorbar(np.arange(3)+(i-1.5)*.07,100*gg.estimate,yerr=100*(gg.hi-gg.estimate),lw=1.2,color=C[law],marker=['o','s','^','D'][i],markersize=3.3,label=law,capsize=2)
    ax.axhline(1,color='#111111',lw=.8,ls='--');ax.set_xticks([0,1,2],['Unlimited','4','2'])
    ax.set_xlabel('Daily supply capacity when available');ax.set_title(title,loc='left',fontsize=9,fontweight='bold');ax.grid(axis='y');ax.set_ylim(-.05,2.5)
axs[0].set_ylabel('Unmet requests over 365 days (%)');axs[0].legend(ncol=2,frameon=False,loc='upper left')
save(fig,'figure5_replenishment_limits')

# A compact table of computed results for manuscript generation and review.
stats={
 'grid_cells':len(g),'maxent_noncertified':int((g.worst_at_maxent>g.epsilon+1e-10).sum()),
 'max_target_ratio':float((g.worst_at_maxent/g.epsilon).max()),
 'median_additional_stock':float((g.S_robust-g.S_maxent).median()),
 'max_additional_stock':int((g.S_robust-g.S_maxent).max()),
 'main_S':chs.to_dict(orient='records')
}
(OUT/'manuscript_numbers.json').write_text(json.dumps(stats,indent=2))
print('Five publication figures generated')
