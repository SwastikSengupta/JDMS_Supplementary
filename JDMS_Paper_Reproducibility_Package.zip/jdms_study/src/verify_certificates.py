"""Exact rational checks of the added unbounded-duration certificate.

This extension was derived after the main simulation run. The manuscript gives
the algebraic proof for all positive integer durations; finite spot checks here
are implementation checks and are not substituted for that proof.
"""
from fractions import Fraction as F
from pathlib import Path
import json

OUT=Path(__file__).resolve().parents[1]/'results'
rows=[]
for S in range(10,129):
    H=2*S-4
    q={3:F(12,H-3),4:1-F(12,H-4),H:F(12,(H-3)*(H-4))}
    assert all(p>=0 for p in q.values()) and sum(q.values())==1
    assert sum(d*p for d,p in q.items())==4
    assert sum(d*d*p for d,p in q.items())==28
    loss=sum(max(d-S,0)*p for d,p in q.items())/20
    assert loss==F(3,10*(2*S-7))
    # Identity: (d-3)(d-4)-(4S-14)(d-S)
    #         = (d-(2S-4))(d-(2S-3)). Both roots are adjacent integers.
    assert -7-(4*S-14)==-((2*S-4)+(2*S-3))
    assert 12+(4*S-14)*S==(2*S-4)*(2*S-3)
    for d in range(1,513):
        P=F((d-3)*(d-4),4*S-14)
        assert P>=max(d-S,0)
    rows.append({'stock':S,'upper_loss_exact':str(loss),'upper_loss':float(loss),
                 'attaining_law':{str(d):str(p) for d,p in q.items() if p}})

assert F(3,290)>F(1,100) and F(3,310)<F(1,100)
optimistic={3:F(1,5),4:F(47,59),63:F(1,295)}
assert sum(optimistic.values())==1
assert sum(d*p for d,p in optimistic.items())==4
assert sum(d*d*p for d,p in optimistic.items())==28
assert sum(max(d-4,0)*p for d,p in optimistic.items())/20==F(1,100)
assert (F(4)-3)/20>F(1,100)  # E[(D-S)+] >= E[D]-S for S <= 3.

result={'all_passed':True,'scope':'Constant unit demand, full restoration, mean U=16, positive integer D with mean 4 and second moment 28; no maximum outage duration.',
 'proof':'For integer d, both (d-3)(d-4) and (d-(2S-4))(d-(2S-3)) are nonnegative. This proves the quadratic majorant globally. Its expectation equals the displayed bound, and a feasible law attains it for every integer S >= 10.',
 'symbolic_identities_and_witnesses_checked':len(rows),'integer_spot_checks':len(rows)*512,
 'worst_case_minimum_stock':19,'minimum_compatible_stock':4,
 'optimistic_attaining_law':{str(d):str(p) for d,p in optimistic.items()},'certificates':rows,
 'design_status':'Post-run analytical extension, not part of the original simulation specification.'}
(OUT/'unbounded_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
print('Exact certificates passed: 119 attaining laws, 60928 integer spot checks; sharp reserve extremes 4 and 19 without a duration cap.')
