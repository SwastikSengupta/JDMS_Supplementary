# JDMS reserve-stock validation study

Executed 10 October 2026. All inputs are constructed benchmarks. No operational data, field calibration, or human participants were used. The author reports that an independent expert reviewed the mathematics after AI-assisted checking; this is distinct from defense-domain or operational validation.

## Main finding

Matching resupply availability, one-step transitions, outage mean, and outage variance does not identify the minimum reserve satisfying a 1% unmet-request target in the stated full-restoration model. Two explicit outage laws require 10 and 14 units. In the main bounded moment class, extreme minimum requirements are 6 and 19 units. An analytical extension proves that without a maximum outage duration the extreme requirements are 4 and 19 units for constant demand.

These findings concern model validation and decision identification. They are not stock recommendations for an actual unit.

## Contents

- `docs/manuscript_source.md`: editable source with semantic reference keys.
- `docs/manuscript.md`: generated source with numbered citations and references.
- `docs/journal_strategy.md`: updated journal audit, closest literature, novelty boundary, and submission checks.
- `docs/references.json`: bibliography used by the manuscript, with source-access levels in the citation ledger.
- `docs/source_audit.csv`: access level and role for each source.
- `docs/final_claim_audit.md`: claim checks, literature boundaries, corrections, and confirmed author declarations.
- `docs/reference_metadata_audit.json`: retrieved DOI registration metadata and recorded access failures.
- `docs/reporting_checklist.md`: study-specific reporting map, informed by STRESS and ADEMP.
- `PROTOCOL.md`: specification saved before numerical execution; not preregistered.
- `EXECUTION_NOTES.md`: changes and disclosure of AI involvement.
- `src/study.py`: exact analysis, cycle Monte Carlo, and separate daily inventory model.
- `src/verify.py`: independent checks, exact finite traces, paired capacity comparisons.
- `src/verify_certificates.py`: exact rational checks of the unbounded-duration analytical extension.
- `src/figures.py`: the five original computed figures.
- `src/build_documents.py`: manuscript and strategy document generation.
- `src/build_publication_pdf.py`: two-column PDF generation using the unchanged Sage journal class.
- `vendor/sagej.cls`: Sage class, with its original conditions of use intact.
- `results/`: complete exact grids, batch aggregates, replication aggregates, checks, and environment.
- `figures/`: PNG (360 dpi) and editable SVG figures.
- `deliverables/`: rendered manuscript PDF, editable DOCX, and strategy PDF.
- `MANIFEST.sha256`: checksums for packaged files.

## Reproduce the numerical study

Use Python 3.12 with the versions in `requirements.txt`. No network or private dataset is needed after installing these dependencies. From this directory:

```bash
python src/study.py --phase all
python src/verify.py
python src/verify_certificates.py
python src/figures.py
```

The study completed in under a minute on the provided runtime, excluding document rendering. Runtime varies by machine. The master seed is 20261010. NumPy SeedSequence keys identify distinct scenarios; capacity comparisons deliberately reuse paths. `results/environment.json` records library versions and source/protocol hashes. Running the commands overwrites generated results. Preserve a copy if comparing against this delivered execution.

The exact phase can run alone with `--phase exact`. Complete-cycle and finite-path phases can run separately with `--phase cycles` and `--phase finite`. Run verification and plotting after all phases for the complete report.

### What is stored

`cycle_batches.csv.gz` holds loss and request totals for each independent batch and stock. `finite_replications.npz` holds per-path losses across stocks and total requests, sufficient to recreate the reported finite-horizon intervals and paired contrasts. Raw daily paths are regenerated from the seeds, not stored. The additional long-horizon daily check is retained as summary estimates and discrepancies. `finite_trace_states.csv` contains the deterministic circular witness.

`verification_report.json` reports 39 passed checks. `unbounded_certificate.json` records 119 exact attaining-law checks and 60,928 integer spot checks accompanying the global algebraic proof. `solver_checks.csv` compares each main-case LP bound with independent vertex enumeration. The positive result means these computations passed these checks; it is not field validation.

### Interpretation cautions

All percentages are fractions of requests left unfilled at the time they occur, not stockout probabilities or readiness percentages. Exact loss bounds are not confidence intervals. Monte Carlo intervals are pointwise and conditional on the simulated law. Undefined intervals in zero-variance samples are intentional. The 324 cells are a designed grid, not a representative sample of organizations.

## Document build

`src/build_documents.py` requires `python-docx` and Pandoc. It creates an editable Word submission manuscript, with tables and figures after the references. `src/build_publication_pdf.py` uses Pandoc and pdfLaTeX to produce the two-column author-manuscript PDF with Sage's journal class. Publisher-only production metadata is omitted. The class itself is unchanged. The PDF uses the same scientific text, tables, and figures as the Word file. The creation environment also rendered the Word file through LibreOffice for page-by-page inspection. Word equations are editable Office Math objects; figures are computed charts, not image-generator outputs.

Run the Word build first to update the numbered Markdown source, then the PDF build:

```bash
python src/build_documents.py
python src/build_publication_pdf.py
```

## Authorship and submission status

The author states that the research, mathematical arguments, computational study, figures, and original manuscript are the author's work. Original AI assistance was limited to grammar, language flow, and checking the mathematics before an independent expert reviewed it. This statement supersedes inaccurate descriptions of those roles in earlier document iterations. The present revision separately discloses assistance with literature discovery, source checking, and revision of the related-work discussion and references using ChatGPT, Consensus, and Undermind.

The package contains a research manuscript, not a journal submission or acceptance. The author confirmed no funding and no conflicts of interest. ORCID 0009-0002-9414-7443 is included in the manuscript and must also be linked in Sage Track. The author must confirm affiliation, coauthor consent if applicable, publication history, rights, and final text before submission. The journal's contradictory preprint and supplemental-file instructions remain unresolved. No journal contact, public repository deposit, or external submission was made in this revision.

## Revision verification

The revision expanded the bibliography from 19 to 28 works and rebuilt all delivered manuscript formats from the same source. It retained the scientific model, numerical study, results, figures, and frozen protocol. Numerical verification was run in an isolated working copy. See `docs/revision_audit.md`, `docs/citation_ledger.csv`, and `docs/document_verification.json` for the executed checks, access limitations, and final layout inspection. `docs/manuscript.tex` is an editable LaTeX source with relative figure paths; the DOCX contains native Office Math.
