---
title: Matching outage statistics does not identify reserve requirements in a defense support model
author: Swastik Sengupta
---

Las Positas College, Livermore, California, USA

Correspondence: swastik.sngpta@gmail.com

ORCID: [0009-0002-9414-7443](https://orcid.org/0009-0002-9414-7443)

## Abstract

**Purpose:** This study tests whether matching resupply availability and outage moments is sufficient to validate a reserve-stock decision in a defense support simulation.

**Methods:** Four outage models share availability, one-step transition probabilities, and outage-duration mean and variance. Renewal calculations and moment bounds identify reserves meeting a 1% unmet-demand limit. An exact proof removes the duration cap for constant demand. Computation covers 324 parameter cells, 12 million renewal cycles, and 192,000 finite-horizon replications.

**Results:** Two matched outage laws require 10 and 14 units under constant demand. A geometric model selects 11 units, leaving 1.923% of requests unmet under the second law. With a 32-day outage cap, the extreme minimum reserves are 6 and 19 units; without a cap, they are 4 and 19. Maximum-entropy selections lack a worst-case certificate in 250 of 324 cells. Limited replenishment also invalidates decisions based on full restoration.

**Conclusion:** These summaries do not identify the reserve requirement. Validation should evaluate demand exceeding the reserve and report decision bounds. The findings establish a validation benchmark for the stated model, without estimating deployed-force performance.

**Keywords:** defense logistics; simulation validation; reserve stock; resupply disruption; distributional uncertainty; renewal reward; moment bounds

## 1 Introduction

A reserve is useful only if it lasts until supplies return. Reproducing supply frequency and average interruption duration does not ensure that a simulator identifies the required reserve. This paper establishes that failure in a support node that holds one consumable. Its decision is the smallest reserve that limits unfilled requests to a stated fraction of demand.

The distinction matters in defense modeling because stock, transport capacity, and support performance are linked. McConnell and colleagues connected uncertainty in an expeditionary logistics network to capacity planning and risk. Choo and colleagues modeled repair spares, maintenance, and aircraft availability in logistical wargaming. Blom and colleagues treated stockout avoidance as the main objective in disrupted defense supply networks.^1,2,3^ These applications give a clear reason to test whether a simplified supply process preserves the decision a simulation supports.

The test developed here is deliberately small. One supply link alternates between working and interrupted periods. When the link works, current requests are filled and reserve stock is restored. During an interruption, the reserve is used until it runs out. There are no routes to optimize and no equipment-performance assumptions to hide a distributional error. The problem concerns consumable availability at a support node, rather than aircraft readiness or the outcome of an operation.

The primary research question is: **When resupply models agree on availability, one-step transition probabilities, and the mean and variance of outage duration, do they identify the same smallest reserve meeting an unmet-demand limit?** The answer is no. Two explicit distributions satisfy those matching conditions but require 10 and 14 units. A common geometric approximation recommends 11 units and understates unmet demand by more than half when assessed against the second distribution.

The paper then asks how much the decision remains uncertain when only those summaries are known. A finite linear program finds the smallest and largest possible shortage at each reserve. Each bound comes with a probability distribution that attains it. This exposes both the risk bound and the outages producing it. The method separates an exactly computed limit from the Monte Carlo error of a simulation run.

This is a study of validation for a specified use. Owen and Chakrabortty identify a need for objective comparisons in defense verification and validation. Pace emphasizes uncertainty beyond individual parameters. Zeigler and Nutaro examine the link between abstract-model properties and the more detailed models to which they are applied.^4,5,6^ Here the use is a reserve decision, and the comparison is whether an input model preserves its service requirement. Matching familiar input statistics is treated as a testable restriction, not as evidence of validity by itself.

The contribution is an executed, reproducible validation benchmark: matched counterexamples, tight reserve bounds, an exact certificate without a maximum outage duration, and a separate implementation testing limited replenishment. It makes the reserve decision and its limits exactly checkable while preserving the input diagnostics under examination.

## 2 Prior work and the precise contribution

### 2.1 Disruption models and service measures

Disruption duration has a central place in inventory research. Tomlin studied mitigation and contingency strategies, including the different consequences of infrequent long disruptions and frequent short disruptions. Snyder and colleagues reviewed the wider operations-research literature on supply interruptions.^7,8^ The importance of outage duration is therefore established; the question here is whether a specified set of matching statistics suffices for a particular reserve decision.

Existing inventory models also distinguish what happens to demand during a disruption. Arreola-Risa and DeCroix optimize an inventory policy when shortages become a mixture of backorders and lost sales. Schmitt, Snyder, and Shen analyze a single-stage system with supply disruptions, stochastic demand, and uncertain yield, and relate its base-stock choices to shortage costs.^9,10^ Those models establish that an inventory recommendation depends on both the supply process and the treatment of unmet demand. The present outcome is the fraction of requests lost immediately, under the explicit restoration rule in Section 3; it is not a backorder cost or equipment-readiness measure.

Balcioglu and Gurler represent normal and disrupted supply periods with phase-type distributions and optimize a continuous-review inventory policy. Their numerical comparisons include outage laws with a common mean but different variances.^11^ Castellano subsequently examines state-dependent base-stock policies with phase-type disruptions.^12^ The present comparison fixes both outage moments as well as availability and one-step transitions. Its distinguishing feature is the exact agreement of these diagnostics alongside disagreement at the reserve acceptance boundary.

Service constraints also require care. Timonina-Farkas, Glogg, and Seifert combine production disruptions and demand-distribution uncertainty through doubly probabilistic service requirements.^13^ A probability of satisfying a service event and a long-run fraction of unfilled requests answer different questions. Their production-scheduling formulation is relevant evidence that distributional uncertainty affects service guarantees, but its guarantees cannot be transferred to the loss fraction used here without changing the model and estimand.

### 2.2 Expected shortage and moment bounds

Distribution-free inventory analysis protects decisions when a distribution is incompletely specified, as illustrated by Gallego and Moon. Bertsimas and Popescu develop a broader optimization approach to bounds under moment information.^14,15^ For a finite discrete support, Prekopa formulates sharp probability and expectation bounds as linear programs.^16^ These are established mathematical foundations for the finite optimization in Section 4.2.

The closest connection is the expected stop-loss transform: the expected excess of a random quantity above a threshold. Courtois and Denuit derive bounds for this transform from moments of integer-valued random variables. Janssens and Ramaekers formulate inventory decisions with incomplete demand information and a service constraint using linear programming. Ninh, Hu, and Allen study distribution-free newsvendor decisions with discrete demand and show why its support structure matters.^17,18,19^ Under constant unit demand, the present expected outage shortage is exactly such a stop-loss transform of outage duration. Sharp shortage bounds, finite-support extremizers, and the use of discrete moment problems in inventory management are consequently prior methods, not new general results claimed here.

This study uses that machinery to test a simulation validation record. It reports the extreme minimum reserves still compatible with the record, provides outage laws attaining the bounds, and makes the constant-demand result checkable through an explicit certificate without a duration cap. The contribution lies in the worked validation benchmark and the precise conditions of its guarantee.

### 2.3 Input selection and simulation uncertainty

Corlu and colleagues review simulation under input uncertainty, while Lam studies sensitivity to serial dependence using robust optimization.^20,21^ For inventory simulation specifically, Akcay and Corlu use a nonparametric Bayesian input model to account for uncertain demand distributions when estimating service levels.^22^ This literature distinguishes uncertainty about an input model from simulation noise conditional on that model. The present calculations make a complementary distinction: exact knowledge of the selected population moments leaves the reserve decision unidentified in the benchmark. Increasing the number of simulation replications cannot resolve that ambiguity.

Maximum entropy is also an established way to select one distribution under incomplete information. Andersson and colleagues compare maximum-entropy newsvendor decisions with conservative alternatives when the demand mean and variance are known.^23^ Here, maximum entropy selects a transparent reference outage law inside the declared bounded class. Its recommendation is then checked against every law in that class. Favorable performance of a fitted distribution and a guarantee over all compatible distributions are separate properties; the benchmark evaluates the latter without claiming that maximum entropy is universally inferior.

### 2.4 The benchmark contribution

The primary contribution is a reproducible test of decision identification under an explicitly stated input-information set. It combines matched population diagnostics, an exact finite-trace witness, attainable reserve bounds, a self-contained unbounded-duration certificate for constant demand, and a separate daily implementation that challenges the restoration assumption. Table 1 identifies the role of the closest prior work. The mathematical tools and the relevance of nonmemoryless disruptions are established; the paper supplies a fully specified instance that makes their implications for a simulation acceptance decision explicit and reproducible.

**Table 1. Relation to the closest research traditions.**

| Research tradition | Established contribution | Focus of this study |
|:--|:--|:--|
| Disrupted inventory systems | Connects interruption laws, inventory policies, and service or cost outcomes | Fixes several input diagnostics and tests whether a reserve decision is identified |
| Non-exponential supply periods | Represents duration shape through phase-type models | Preserves mean and variance while changing duration shape |
| Discrete moment and stop-loss bounds | Computes sharp expected-shortage bounds under incomplete distributional information | Supplies attainable reserve bounds and a worked integer-duration certificate |
| Inventory service constraints | Uses incomplete demand information to support service-constrained stock decisions | Treats the remaining stock range as a validation outcome |
| Maximum-entropy input selection | Selects a distribution from limited moment information | Checks the selected reserve over the entire declared moment class |
| Simulation input uncertainty | Separates uncertain inputs from Monte Carlo variability | Isolates population-moment non-identification and tests guarantee transfer under limited replenishment |

## 3 Support node and outcome

### 3.1 Events and assumptions

A cycle contains a normal-supply spell of $U$ days followed by an outage of $D$ days. Spells are positive integers. Successive cycles are independent, and $U$ and $D$ are independent within a cycle. The main normal spell is geometric with mean 16 days, meaning that the chance of ending a normal spell is the same each day. An outage begins with a full reserve of $S$ units. Daily requests are independent of supply spells and of each other. Each request uses one unit.

During normal supply, requests are served and the reserve is full by the end of the day. During an outage, requests draw down that reserve. Requests exceeding available stock are recorded as unfilled at the time of request and leave the system. They are not backlogged. Thus the outcome describes immediate fulfillment of consumable demand. It does not count delayed repairs, queueing time, or mission cancellations.

The baseline has one request each day. Two additional demand laws preserve that mean: Poisson demand has variance 1, and negative-binomial demand has variance 3. The latter represents more uneven demand. Its daily shape parameter is $1/2$ and success probability is $1/3$, using the failures-before-successes convention. Over $d$ outage days, total demand is Poisson with mean $d$, or negative binomial with shape $d/2$ and success probability $1/3$. Table 2 gives the primary inputs.

**Table 2. Main constructed benchmark. Values are study choices, not estimated military parameters.**

| Quantity | Value or definition |
|:--|:--|
| Normal-supply duration | Geometric on positive integers; mean 16 days |
| Mean outage duration | 4 days |
| Outage variance | 12 days squared |
| Long-run supply availability | 0.80 |
| Daily request mean | 1 unit |
| Daily request variance | 0, 1, or 3 |
| Reserve decision | Smallest nonnegative integer $S$ meeting the loss limit |
| Main loss limit | 1% of requests unfilled |
| Bounded audit | Outage support 1 through 32 days |
| Restoration | Full reserve at each outage start |

### 3.2 The quantity being estimated

Let $X_d$ be total demand over an outage of $d$ days. Define $h_S(d)$ as the expected demand beyond the reserve. The notation $(x)^+$ means the larger of $x$ and zero. With daily mean demand $\lambda$, the long-run fraction of unfilled requests is

$$h_S(d)=\mathrm{E}[(X_d-S)^+],\qquad L(S)=\frac{\mathrm{E}[h_S(D)]}{\lambda\,\mathrm{E}[U+D]}.\qquad (1)$$

Equation (1) follows by summing unfilled and total requests over complete cycles and taking their ratio. All unfilled requests occur during outages in the restoration model. The numerator is expected loss per cycle. The denominator is expected requests per cycle. It is a ratio of expectations, not the average of cycle-specific percentages; short cycles must not receive the same weight as long ones.

The reserve choice at loss limit $\epsilon$ is

$$S^*(\epsilon)=\min\{S\in\mathbb{Z}_{\geq0}:L(S)\leq\epsilon\}.\qquad (2)$$

The 1% limit is an experimental threshold, not a military readiness standard. The complement of $L$ is the request fill fraction. It is distinct from the chance of experiencing at least one shortage, which can be large even when few requests are missed. Under constant unit demand, $h_S(d)=(d-S)^+$. This makes the main counterexample transparent: every outage day after the reserve is exhausted adds one unfilled request.

### 3.3 Four models with matching summaries

Model A has a two-day outage with probability $3/4$ and a ten-day outage with probability $1/4$. Model B has a three-day outage with probability $12/13$ and a sixteen-day outage with probability $1/13$. Model G is geometric with mean four. Model E maximizes entropy on integer durations 1 through 32 subject to the same first two moments. E supplies a baseline inside the bounded class used for the audit. G is an unbounded reference and is not treated as a member of that bounded class.

All four satisfy $\mathrm{E}[D]=4$ and $\mathrm{E}[D^2]=28$, hence variance 12. E is found by solving for probabilities proportional to $\exp(a d+b d^2)$ under the two moment constraints. Figure 1 shows four distinct duration distributions with those same summaries. A and B were selected as analytical counterexamples. Their probabilities are not estimates of how often such environments occur.

![Four outage distributions with identical first two moments.](../figures/figure1_outage_laws.png){width=6.3in}

**Figure 1. Constructed outage distributions.** All have mean 4 days and variance 12 days squared. G continues beyond the displayed range; E is bounded at 32. The normal-supply law is common to all four.

## 4 The validation audit

### 4.1 Why the usual summaries cannot identify the decision

Let state 1 denote normal supply and state 0 an outage. In a stationary alternating process, availability and the probabilities of changing state in the next day are

$$A=\frac{\mathrm{E}[U]}{\mathrm{E}[U]+\mathrm{E}[D]},\quad p_{10}=\frac{1}{\mathrm{E}[U]},\quad p_{01}=\frac{1}{\mathrm{E}[D]}.\qquad (3)$$

Each completed spell contributes one transition out of its state. Dividing transitions by the number of days spent in that state gives (3), whether or not durations are geometric. The four models therefore share $A=0.8$, $p_{10}=1/16$, and $p_{01}=1/4$. Their lag-one state correlation is also identical, at $1-p_{10}-p_{01}=0.6875$. This does not make A, B, or E first-order Markov processes: their transition probabilities depend on time already spent in the current spell.

The matching extends to one further common diagnostic. Let $\widehat A_T$ be the fraction of $T$ days with normal supply. The regenerative variance coefficient is

$$v=\frac{\mathrm{Var}[(1-A)U-AD]}{\mathrm{E}[U+D]}=0.864,\qquad T\,\mathrm{Var}(\widehat A_T)\longrightarrow v.\qquad (4)$$

For the main independent spells, $\mathrm{Var}(U)=240$ and $\mathrm{Var}(D)=12$, which gives the same value in all four models. Equation (4) is an asymptotic result, not a claim of identical finite-horizon availability distributions.

Despite these equalities, constant-demand losses under A and B are different. For stocks between 3 and 10, A contributes $(10-S)/80$ and B contributes $(16-S)/260$ to $L(S)$. Above 10, A contributes zero while B continues to lose requests until stock reaches 16. At a 1% limit, A first passes at 10 and B at 14. This explicit construction proves that the matching conditions do not determine the decision.

### 4.2 Tight bounds over all matching outage laws

Suppose the audit has a defensible upper duration $M$ as well as mean $\mu$ and second moment $m_2$. Let $q_d$ be the probability of a $d$-day outage. At each reserve, solve both the minimizing and maximizing versions of

$$\min_q\sum_{d=1}^{M}q_d h_S(d)\quad\mathrm{or}\quad\max_q\sum_{d=1}^{M}q_d h_S(d)$$

subject to

$$\sum_{d=1}^{M}q_d=1,\quad\sum_{d=1}^{M}d q_d=\mu,\quad\sum_{d=1}^{M}d^2q_d=m_2,\quad q_d\geq0.\qquad (5)$$

Divide the two optima by the denominator of (1) to obtain $L_-(S)$ and $L_+(S)$. These are attained bounds, not simulation confidence intervals. The feasible set is a compact polytope, and its linear objective attains an optimum at a vertex. At most three durations need positive probability because there are three equality constraints. This allows a second implementation to enumerate all candidate vertices and check the solver.

For the stated information set, $L_+(S)\leq\epsilon$ certifies the reserve. If $L_-(S)>\epsilon$, every compatible law fails. If the bounds straddle the limit, the summaries leave the decision unresolved. That third outcome is useful: it identifies missing distributional information before a model-based recommendation is treated as settled.

The smallest passing reserve under the lower curve is the minimum possible requirement over compatible laws. The smallest reserve passing the upper curve is the maximum possible requirement. This identifies the extreme reserve requirements. It does not attach probabilities to them or assume that the worst case is common.

### 4.3 An exact certificate without a maximum outage duration

The constant-demand benchmark admits a stronger result. The following calculation specializes the dual-majorant approach underlying moment bounds and supplies a self-contained certificate for this benchmark.^16,17^ Retain $\mathrm{E}[D]=4$ and $\mathrm{E}[D^2]=28$, but allow every positive integer duration. Write $L_+^{\infty}(S)$ for the largest loss over this class. For every integer $S\geq10$, define the quadratic function

$$P_S(d)=\frac{(d-3)(d-4)}{4S-14},\qquad P_S(d)-(d-S)=\frac{(d-(2S-4))(d-(2S-3))}{4S-14}.\qquad (6)$$

Both products in (6) are nonnegative at every integer $d$: each pair of roots consists of consecutive integers. Thus $P_S(d)$ is at least zero and at least $d-S$, so it bounds $(d-S)^+$ from above. Taking expectations uses only the two known moments. Since $\mathrm{E}[(D-3)(D-4)]=28-7(4)+12=12$ and the mean cycle demand is 20, this gives

$$L_+^{\infty}(S)=\frac{3}{10(2S-7)},\qquad S\in\mathbb{Z},\ S\geq10.\qquad (7)$$

Equality, rather than merely an upper bound, follows from an explicit outage law. Put $H=2S-4$ and assign probabilities $q_3=12/(H-3)$, $q_4=1-12/(H-4)$, and $q_H=12/[(H-3)(H-4)]$. These probabilities are nonnegative, sum to one, have the required moments, and attain the bound. The proof therefore does not depend on a numerical optimizer or a truncation of the duration range.

At 18 units, (7) gives $3/290=1.0345\%$; at 19 it gives $3/310=0.9677\%$. Nineteen is consequently the exact worst-case minimum reserve even without a duration cap. At 19, an attaining law assigns probabilities $12/31$, $3/5$, and $2/155$ to outages of 3, 4, and 34 days.

The minimum compatible requirement is four units. For $S\leq3$, $\mathrm{E}[(D-S)^+]\geq4-S$ makes loss at least 5%. At $S=4$, probabilities $1/5$, $47/59$, and $1/295$ at durations 3, 4, and 63 give the required moments and loss exactly 1%. Thus the extreme requirements are 4 and 19 without a cap. This certificate is specific to constant unit demand and full restoration; it does not cover random demand or limited replenishment.

### 4.4 What the audit asks an analyst to retain

For constant demand, the expected excess duration equals the following sum of tail probabilities:

$$\mathrm{E}[(D-S)^+]=\sum_{k=S+1}^{\infty}\Pr(D\geq k).\qquad (8)$$

The sum measures how much outage remains after stock is exhausted. A mean and a variance do not fix that sum. With random demand, the corresponding quantity is the expected excess of outage demand. An input-validation record should therefore retain the empirical duration distribution or the relevant expected-excess curve, together with uncertainty about that curve. The moment audit is appropriate when only moments are available; it does not replace richer evidence when richer evidence exists.

## 5 Computational methods

### 5.1 Design and reporting

The experimental specification was saved before executing the main numerical study. It is a local run specification, not a preregistration. Reporting is organized around explicit inputs, events, outcomes, implementation, and uncertainty, drawing on STRESS and the aims, data-generating mechanisms, estimands, methods, and performance measures approach to simulation studies.^24,25^ No operational dataset, human participant, or defense-domain validation was used.

The analytical certificate in Section 4.3 was derived during revision, after the original numerical runs. It is an extension of the benchmark, not a prespecified confirmatory experiment. Its algebra and attaining distributions are also checked with exact rational arithmetic in the accompanying code.

The exact sensitivity grid crosses outage means 2, 4, and 6 days; variance $\mu(\mu-1)$; maximum durations $4\mu$, $8\mu$, and $16\mu$; availability 0.70, 0.80, 0.90, and 0.95; loss limits 0.5%, 1%, and 2%; and the three demand laws. This gives 324 cells. Normal-spell means are adjusted to keep the chosen availability. The grid tests variations of the mechanism; it is not sampled from a population of defense units.

Each cell compares the minimum reserve under maximum entropy with the tight upper bound at that reserve. The geometric choice is recorded as a secondary comparison, with its unbounded support explicitly distinguished. Every cell is retained. The baseline E is recomputed for each mean and duration bound, so comparisons do not silently move it outside the allowed class.

### 5.2 Exact and stochastic computation

Losses for bounded distributions are evaluated by finite sums. For G, durations 1 through 1024 are summed; the omitted expected-duration mass is below $10^{-75}$ even at the largest grid mean of six. Expected Poisson and negative-binomial excesses use survival-function identities, checked independently against direct probability-mass summation. The moment solver uses scaled equality constraints, checks primal and dual feasibility, and checks the duality gap.

The complete-cycle Monte Carlo experiment uses 200 independent batches of 5000 cycles for each of four outage laws and three demand laws, totaling 12 million cycles. The mean is estimated as total loss divided by total requests across batches. If batch $b$ contains loss $Y_b$ and requests $Z_b$, the standard error is

$$\widehat L=\frac{\sum_bY_b}{\sum_bZ_b},\qquad
\operatorname{SE}(\widehat L)=\frac{s(Y_b-\widehat L Z_b)}{\sqrt{B}\,\overline Z}.\qquad (9)$$

Approximate pointwise 95% intervals use a $t$ critical value with $B-1$ degrees of freedom. The independent unit is a batch, not a day. These intervals quantify Monte Carlo uncertainty conditional on the known generating law. They contain no allowance for uncertainty in a real unit's demand or outage process. Where a simulation observes no variability, an interval is left undefined; a zero-event sample is not reported as proof of zero risk.

### 5.3 A separate daily model

A second simulator advances one day at a time and tracks inventory directly. It crosses the four outage laws, constant or Poisson demand, 90- or 365-day horizons, and normal-day supply capacities of 2, 4, or unlimited units. Each of the 48 cells has 4000 independent replications, totaling 192,000 replication paths. Stocks 0 through 32 are evaluated on the same path within each replication. Capacity comparisons use identical random streams. This permits paired comparisons without making daily observations independent.

Each path starts with full stock at the beginning of a new normal spell. With finite capacity, arrivals are added, requests are served from arrivals plus stock, and ending inventory is capped at $S$. On an outage day, no arrivals occur. With unlimited capacity, all normal-day requests are served and ending stock equals $S$. Finite-horizon estimates divide total unfilled requests by total requests across replications; they estimate a ratio of finite-horizon expectations, not the average replication-level percentage.

The full-restoration formula is checked separately using 1000 daily paths of 12,000 days for each law with Poisson demand. These verification paths are additional to the 192,000 finite-horizon paths. The code uses NumPy's default generator with explicit SeedSequence keys and master seed 20261010. Exact software versions, seeds, all batch totals, finite-horizon replication totals, and verification outputs accompany the study.

## 6 Results

### 6.1 Matched models select different stocks

Table 3 gives the minimum reserves from exact calculation. At constant demand, A and B require 10 and 14 units, a 40% difference despite identical listed diagnostics. G and E both choose 11. Under B, that reserve leaves $5/260=1.9231\%$ of requests unmet, whereas G predicts 0.8447% and E predicts 0.8489%. The error is therefore a false pass against the 1% requirement, not merely a small change in a ranking.

**Table 3. Exact minimum reserve and the unmet fraction at that reserve for the 1% limit.**

| Outage law | Constant demand | Poisson demand | Negative-binomial demand |
|:--|--:|--:|--:|
| A | 10 units; 0.000% | 12 units; 0.664% | 15 units; 0.892% |
| B | 14 units; 0.769% | 15 units; 0.816% | 17 units; 0.916% |
| G | 11 units; 0.845% | 12 units; 0.969% | 16 units; 0.827% |
| E | 11 units; 0.849% | 12 units; 0.972% | 16 units; 0.827% |

Increasing demand variability raises the stock requirement. It does not remove the disagreement between outage models. Under Poisson demand, A, G, and E select 12 units while B requires 15. The selected stock is not a smooth function of the loss estimate because the stock is an integer: the next unit can move a model from above the limit to below it. Figure 2 shows that boundary directly.

![Reserve loss curves for constant and Poisson demand.](../figures/figure2_reserve_decisions.png){width=6.3in}

**Figure 2. Exact shortage curves and reserve choices.** Markers show each model's smallest reserve satisfying the 1% line. G and E nearly overlap. The crossing of the loss limit, rather than overall curve similarity, determines the decision.

### 6.2 Sharp reserve bounds with and without a duration cap

For constant demand and a 32-day maximum outage, the first two moments permit minimum reserve requirements as small as 6 units and as large as 19. E selects 11. At 11, the upper unmet-demand bound is exactly 2%, more than twice E's prediction. At 18, the bound remains 1.0345%; at 19, it falls to 0.9606%. Thus 19 is the smallest reserve certified over the stated class. It is eight units above the E recommendation, a 72.7% increase.

These are sharp values for the specified class. Table 4 supplies simple distributions attaining selected upper bounds. The worst distribution at 11 is different from the one near 19. A single severe scenario therefore need not expose the largest error at every candidate reserve. Figure 3 shows the whole bound.

**Table 4. Attainable witnesses for the constant-demand upper bound. Each has mean 4 and second moment 28.**

| Evaluated stock | Positive-probability outage lengths and probabilities | Unmet fraction |
|--:|:--|--:|
| 11 | 3 days: 4/5; 4 days: 1/7; 18 days: 2/35 | 2.0000% |
| 18 | 3 days: 12/29; 4 days: 4/7; 32 days: 3/203 | 1.0345% |
| 19 | Same distribution as the preceding row | 0.9606% |

![Tight shortage bounds over moment-matched outage laws.](../figures/figure3_identified_bounds.png){width=6.3in}

**Figure 3. What the moment information leaves unresolved.** Shading spans the tight lower and upper bounds for constant demand, 80% supply availability, and outage support 1 through 32 days. The upper bound crosses the requirement at 19 units. This region represents distributional ambiguity, not a confidence band.

The duration bound changes the conclusion. At a 16-day maximum, the certified stocks for constant, Poisson, and negative-binomial demand are 14, 15, and 17. At a 32-day maximum, they are 19, 19, and 20. Extending the maximum to 64 leaves these three upper reserve requirements unchanged. However, the smallest compatible requirement falls in some cells. An observed maximum is not automatically a valid support bound: a claim that longer outages are impossible needs justification independent of this calculation.

For constant demand, the exact result in Section 4.3 removes that support assumption altogether. The upper loss at 19 rises slightly to 0.9677%, still below 1%, while the smallest compatible requirement falls to four units. Thus the 19-unit worst-case requirement is not an artifact of choosing a 32-day cap. The corresponding statement for random demand has not been proved here.

### 6.3 Sensitivity over the complete design

Maximum-entropy choices fail the upper-bound test in 250 of 324 cells. In the remaining 74, the selected integer stock also satisfies the upper bound. Across the designed grid, the largest worst-case loss at an E-selected reserve is 4.286 times the corresponding target. The median increase from E stock to certified stock is two units, and the maximum increase is 46. These are descriptions of the specified grid, not estimates of the rate of incorrect decisions in operational models.

Figure 4 shows why the result should be reported as a decision range rather than a universal safety factor. The added stock varies with availability, the service target, demand variability, and the duration bound. Some E choices are already certified because rounding to the next integer gives enough margin. Others remain far from a certificate even though the fitted distribution exactly reproduces the moments.

![Stock selections and certified reserves across 324 parameter cells.](../figures/figure4_sensitivity.png){width=6.3in}

**Figure 4. All 324 designed cells.** Each panel has 108 cells; overlapping points are retained. Points above the diagonal require more stock to cover every matching bounded distribution than maximum entropy selects. Color and shape identify the loss limit. No frequency interpretation is attached to point density.

### 6.4 Numerical verification

Independent enumeration finds 436 distinct feasible vertices for the main 32-day moment class. Across 147 stock-demand combinations, both lower and upper linear-programming results agree with enumeration. The largest discrepancy is $2.10\times10^{-12}$ requests per cycle. Direct probability-mass sums also agree with the stochastic-demand excess formulas within $10^{-10}$.

For the unbounded constant-demand certificate, exact rational checks verify the moments and attained losses for stocks 10 through 128. The global guarantee comes from the factorization in (6); finite checks supplement that proof rather than establish it. The certificate reproduces the bounded upper losses whenever its attaining law lies within the chosen duration cap.

The cycle simulation estimates B's loss at 11 units under constant demand as 1.9214%, with a 95% Monte Carlo interval of 1.9094% to 1.9335%. The exact value is 1.9231%. G's estimate is 0.8477%, with interval 0.8359% to 0.8594%, compared with the exact 0.8447%. Those intervals are much narrower than the disagreement between the models. Additional simulation replications reduce sampling noise without correcting the misspecified outage distribution.

The largest finite standardized discrepancy from the exact curve is 3.31 standard errors in the cycle experiment and 1.76 in the independent daily verification. These are descriptive diagnostics over many comparisons, not familywise acceptance tests. Zero-variance estimates are excluded from that diagnostic. Code checks also confirm nonnegative inventory, inventory caps, loss bounded by total demand, and pathwise nonincreasing loss as reserve increases. The executed checks support numerical correctness for the implemented model. They do not establish empirical validity, consistent with the distinction emphasized by Sargent.^26^

### 6.5 Limited replenishment exposes the restoration assumption

The finite-horizon test shows a second source of false assurance. Under constant demand, B with 14 units loses 0.7402% of requests over 365 days with unlimited replenishment. Reducing normal-day capacity to two units increases the estimate to 1.0674%, with a pointwise 95% Monte Carlo interval of 1.0295% to 1.1053%. The reserve now fails the 1% target. Some normal spells end before inventory is rebuilt.

At 11 units, E loses 0.8403% under unlimited supply but 1.2917% with capacity two. Under Poisson demand, E at its selected 12 units rises from 0.9204% to 1.6310%. Figure 5 reports all four laws at these representative stock choices. The full 90- and 365-day results are retained in the artifact. The 365-day unlimited estimates are not required to equal the long-run values because every run begins with full stock in a new normal spell.

![Finite-horizon loss under restricted replenishment.](../figures/figure5_replenishment_limits.png){width=6.3in}

**Figure 5. The reserve must be restored for the renewal certificate to apply.** Points show ratios over 4000 independent 365-day paths per cell; bars are pointwise 95% Monte Carlo intervals. Stocks are the E-selected values from the restoration model. Capacities use the same paths within each law and demand setting. A zero-variance cell has no estimated interval.

## 7 Use in defense simulation practice

The audit gives an analyst a concrete acceptance question: does every outage law still allowed by the validation evidence produce an acceptable result at the recommended stock? If not, the evidence does not settle that recommendation. Resolving that failure requires additional distributional evidence or a reserve that satisfies the bound.

To apply the test, first state the actual decision and service measure. A request fill fraction, a chance of any stockout, and equipment readiness require different loss functions. Next record the supply-spell definition, demand process, restoration rule, and justified duration range. Then compute the expected-excess curve or its bounds at the proposed stock and the stock immediately below it. Retain an attaining outage distribution for any failed certificate. Finally, test the restoration rule in the model where the decision will be used. A reserve selected in a reset model should not inherit a guarantee in a model that retains inventory deficits.

This workflow complements empirical validation. Cummings and colleagues, for example, compared flight-deck simulation measures with operational evidence and examined sensitivity.^27^ Using this study's numerical stocks for an actual unit requires comparable external evidence. The present audit instead checks whether a specified set of input facts logically supports a modeled decision. It is suitable as a small regression benchmark for changes to supply-input generators and as a record of unresolved distributional uncertainty.

The result also helps allocate data collection. When the feasible loss range straddles the requirement, collecting more observations solely to estimate the same two moments is not enough in principle. The outage tail near and beyond the selected reserve matters. If replenishment is slow, outage demand must be considered together with the stock present at outage start and the recovery between spells. The validation target is then a joint process, not a duration histogram alone.

## 8 Limits of the claim

The study is primary computational research using constructed inputs. It has no field calibration. Its numerical reserves should not be inserted into a procurement or operational plan. The defense relevance comes from the support decision and from the validation problem shared with defense logistics models, not from a claim that a particular deployed system has 80% resupply availability.

The baseline is a single item at a single node. It excludes repair loops, perishability, substitutes, transport competition, strategic adversaries, and demand that rises during disruptions. Full restoration is a strong assumption. The independent daily experiment shows why it matters, but does not produce tight bounds for every capacitated inventory model. Likewise, independence of normal and outage spells excludes persistent common causes. Validation of models with those dependencies requires a joint input description.

The moments and, in the bounded audit, the support bound are treated as known. If they are estimated, confidence regions for those inputs must replace exact equalities and the feasible set must be reconsidered. That extension was not executed here. The maximum-entropy model is a transparent baseline, not the empirically best fit to a real dataset. The geometric model is included because it offers a simple memoryless reference, not because the study establishes its prevalence in JDMS papers.

The grid and the example laws are designed experiments. They establish existence, mechanism, and sensitivity within declared conditions. They do not establish how often model errors occur in defense organizations. Hofmann's discussion of data farming provides a relevant caution: extensive computational exploration does not itself supply external validity.^28^ Nor does a small Monte Carlo interval account for uncertainty about whether the modeled system represents its intended application.

## 9 Conclusion

Availability, one-step transitions, and the first two outage moments do not identify the reserve needed to meet a supply-service target in the stated model. Two exactly matched laws require 10 and 14 units. Within a 32-day bounded class, the same information permits extreme minimum requirements of 6 and 19. An exact proof shows that 19 remains the worst-case requirement for constant demand even when outage duration is unbounded. The practical response is to validate the expected demand beyond the reserve, report the range still allowed by the evidence, and preserve the replenishment assumptions on which any certificate depends. Field use requires evidence about the particular support system.

## Acknowledgements

The author conducted the research and prepared the manuscript. AI assistance in the original work was limited to grammar correction, improvements to language flow, and checking the mathematics. An independent expert subsequently reviewed the mathematical content. For this revision, ChatGPT, Consensus, and Undermind assisted with literature discovery, source checking, and revision of the literature review and references. The author retains full responsibility for the manuscript's accuracy and conclusions.

## Statements and Declarations

### Ethical considerations

The study involves mathematical models and computer-generated random inputs. It uses no human participants, personal records, animals, or operational military data. Ethics approval for human-participant research is not applicable.

### Consent to participate

Not applicable.

### Consent for publication

Not applicable.

### Declaration of conflicting interest

The author declares no conflicts of interest.

### Funding statement

The author received no financial support for the research, authorship, or publication of this article.

### Data availability

The source code, run specification, numerical outputs, simulation aggregates, and figure-generation scripts are included in the accompanying reproducibility package.

## Appendix A An exact finite trace witness

The failure is not an artifact of comparing population parameters with noisy sample estimates. Construct two circular traces, each containing 52 normal spells of 16 days. Trace A contains 39 outages of two days and 13 of ten days. Trace B contains 48 outages of three days and four of sixteen days. Each trace has 1040 days, including 832 normal days and 208 outage days. Both have exactly 80% availability, mean outage 4, and second outage moment 28.

Including the wraparound transition, both have 52 normal-to-outage transitions, 52 outage-to-normal transitions, 780 normal-to-normal transitions, and 156 outage-to-outage transitions. Their fitted one-step transition matrices are therefore identical. At reserve 11, A loses no requests and B loses 20, exactly 1.9231% of 1040 requests. At reserve 14, B loses eight requests. This witness uses fixed normal spells solely to give exact finite counts; the main experiments retain geometric normal spells. The complete traces and a checker are included in the artifact.

## References

1\. McConnell BM, Hodgson TJ, Kay MG, et al. Assessing uncertainty and risk in an expeditionary military logistics network. J Def Model Simul 2021; 18(2): 135-156. https://doi.org/10.1177/1548512919860595

2\. Choo N, Ahner D and Champagne L. The effects of aircraft use and available repair spares on aircraft sortie generation: a long-duration logistical wargaming simulation tool. J Def Model Simul 2023; 20(2): 111-130. https://doi.org/10.1177/15485129211040782

3\. Blom M, Shekh S, Gossink D, et al. Inventory routing for defense: Moving supplies in adversarial and partially observable environments. J Def Model Simul 2020; 17(1): 55-81. https://doi.org/10.1177/1548512918798056

4\. Owen KR and Chakrabortty RK. Verification, validation, and accreditation for models and simulations in the Australian defence context: a review. J Def Model Simul 2024; 21(2): 205-227. https://doi.org/10.1177/15485129221134632

5\. Pace DK. Comprehensive consideration of uncertainty in simulation use. J Def Model Simul 2013; 10(4): 367-380. https://doi.org/10.1177/1548512912455471

6\. Zeigler BP and Nutaro JJ. Towards a framework for more robust validation and verification of simulation models for systems of systems. J Def Model Simul 2016; 13(1): 3-16. https://doi.org/10.1177/1548512914568657

7\. Tomlin B. On the value of mitigation and contingency strategies for managing supply chain disruption risks. Manage Sci 2006; 52(5): 639-657. https://doi.org/10.1287/mnsc.1060.0515

8\. Snyder LV, Atan Z, Peng P, et al. OR/MS models for supply chain disruptions: a review. IIE Trans 2016; 48(2): 89-109. https://doi.org/10.1080/0740817X.2015.1067735

9\. Arreola-Risa A and DeCroix GA. Inventory management under random supply disruptions and partial backorders. Nav Res Logist 1998; 45(7): 687-703. https://doi.org/10.1002/(SICI)1520-6750(199810)45:7%3C687::AID-NAV3%3E3.0.CO;2-7

10\. Schmitt AJ, Snyder LV and Shen ZJM. Inventory systems with stochastic demand and supply: properties and approximations. Eur J Oper Res 2010; 206(2): 313-328. https://doi.org/10.1016/j.ejor.2010.02.029

11\. Balcioglu B and Gurler U. On the use of phase-type distributions for inventory management with supply disruptions. Appl Stoch Models Bus Ind 2011; 27(6): 660-675. https://doi.org/10.1002/asmb.879

12\. Castellano D. On the optimality of state-dependent base-stock policies for an inventory system with PH-type disruptions. Logistics 2025; 9(4): 165. https://doi.org/10.3390/logistics9040165

13\. Timonina-Farkas A, Glogg RY and Seifert RW. Limiting the impact of supply chain disruptions in the face of distributional uncertainty in demand. Prod Oper Manag 2022; 31(10): 3788-3805. https://doi.org/10.1111/poms.13781

14\. Gallego G and Moon I. The distribution free newsboy problem: review and extensions. J Oper Res Soc 1993; 44(8): 825-834. https://doi.org/10.1057/jors.1993.141

15\. Bertsimas D and Popescu I. Optimal inequalities in probability theory: a convex optimization approach. SIAM J Optim 2005; 15(3): 780-804. https://doi.org/10.1137/S1052623401399903

16\. Prekopa A. The discrete moment problem and linear programming. Discrete Appl Math 1990; 27(3): 235-254. https://doi.org/10.1016/0166-218X(90)90068-N

17\. Courtois C and Denuit M. Moment bounds on discrete expected stop-loss transforms, with applications. Methodol Comput Appl Probab 2009; 11(3): 307-338. https://doi.org/10.1007/s11009-007-9048-0

18\. Janssens GK and Ramaekers KM. A linear programming formulation for an inventory management decision problem with a service constraint. Expert Syst Appl 2011; 38(7): 7929-7934. https://doi.org/10.1016/j.eswa.2010.12.009

19\. Ninh A, Hu H and Allen D. Robust newsvendor problems: effect of discrete demands. Ann Oper Res 2019; 275(2): 607-621. https://doi.org/10.1007/s10479-018-3016-7

20\. Corlu CG, Akcay A and Xie W. Stochastic simulation under input uncertainty: a review. Oper Res Perspect 2020; 7: 100162. https://doi.org/10.1016/j.orp.2020.100162

21\. Lam H. Sensitivity to serial dependency of input processes: a robust approach. Manage Sci 2018; 64(3): 1311-1327. https://doi.org/10.1287/mnsc.2016.2667

22\. Akcay A and Corlu CG. Simulation of inventory systems with unknown input models: a data-driven approach. Int J Prod Res 2017; 55(19): 5826-5840. https://doi.org/10.1080/00207543.2017.1343503

23\. Andersson J, Jornsten K, Nonas SL, et al. A maximum entropy approach to the newsvendor problem with partial information. Eur J Oper Res 2013; 228(1): 190-200. https://doi.org/10.1016/j.ejor.2013.01.031

24\. Monks T, Currie CSM, Onggo BS, et al. Strengthening the reporting of empirical simulation studies: Introducing the STRESS guidelines. J Simul 2019; 13(1): 55-67. https://doi.org/10.1080/17477778.2018.1442155

25\. Morris TP, White IR and Crowther MJ. Using simulation studies to evaluate statistical methods. Stat Med 2019; 38(11): 2074-2102. https://doi.org/10.1002/sim.8086

26\. Sargent RG. Verification and validation of simulation models. J Simul 2013; 7(1): 12-24. https://doi.org/10.1057/jos.2012.20

27\. Cummings ML, Li S, Han H, et al. Modeling efficiency and safety on an aircraft carrier flight deck. J Def Model Simul 2024; 21(4): 441-452. https://doi.org/10.1177/15485129221150939

28\. Hofmann M. Simulation-based exploratory data generation and analysis (data farming): a critical reflection on its validity and methodology. J Def Model Simul 2013; 10(4): 381-393. https://doi.org/10.1177/1548512912472941
