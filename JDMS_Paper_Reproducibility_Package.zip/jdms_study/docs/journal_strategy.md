---
title: JDMS manuscript revision and submission review
author: Swastik Sengupta
date: 11 October 2026
---

## The paper and its contribution

The revised manuscript asks whether outage models with matching availability, one-step transitions, and outage mean and variance identify the same minimum reserve under a fixed request-loss limit. The answer is negative in the declared support-node model: two matched laws require 10 and 14 units. Tight bounds and attaining distributions show the remaining decision range. The exact constant-demand certificate retains a 19-unit worst-case requirement when the duration cap is removed.

The paper is strongest as a reproducible validation benchmark. Supply-disruption inventory models, discrete moment linear programs, and sharp expected-shortage bounds are established methods. The revision now credits the closest work directly and avoids presenting these methods as new general theory. The numerical inputs are constructed; no operational stock recommendation or field-validation claim is made.

## Literature added and why it matters

The narrative literature review was expanded from 19 to 28 published references. Consensus and Undermind were used for discovery, followed by publisher or author-institution checks. Citation count was not used as a substitute for relevance. The primary-source ledger records what was inspected and limits each attribution to that evidence.

| Added work | Role in the revised argument |
|:--|:--|
| Arreola-Risa and DeCroix 1998 | Distinguishes disrupted inventory with backorders and lost sales from the manuscript's immediate request-loss outcome |
| Schmitt, Snyder, and Shen 2010 | Connects stochastic supply and demand with base-stock and shortage-cost decisions |
| Timonina-Farkas, Glogg, and Seifert 2022 | Shows why a probabilistic service guarantee differs from a long-run unmet-demand fraction |
| Prekopa 1990 | Credits the discrete moment linear-programming foundation |
| Courtois and Denuit 2009 | Credits the directly relevant discrete expected stop-loss bounds |
| Janssens and Ramaekers 2011 | Recognizes prior service-constrained inventory decisions under incomplete distributional information |
| Ninh, Hu, and Allen 2019 | Establishes the importance of discrete support in robust newsvendor models |
| Akcay and Corlu 2017 | Separates uncertain inventory input models from simulation noise |
| Andersson and colleagues 2013 | Places maximum-entropy selection in its existing inventory literature |

The paper's Table 1 now compares specific methodological traditions, and Section 4.3 attributes the certificate to the established dual-majorant approach. The review is targeted and narrative. It does not establish worldwide priority. The institutional Courtois and Denuit working paper was inspected for methodological context, while the published 2009 article is cited. For Ninh and colleagues, 2019 is the issue year; 2018 is the online publication year.

## Authorship and assistance

The author states that the research and original manuscript are the author's work. Original AI assistance was limited to grammar correction, language flow, and checking the mathematics, followed by independent expert review of the mathematical content. This corrected account replaces inaccurate descriptions in earlier iterations.

The current revision separately discloses assistance with literature discovery, source checking, and revision of the related-work discussion and references using ChatGPT, Consensus, and Undermind. It does not attribute the research design, original code, figures, or mathematical derivation to AI. Expert mathematical review is distinct from empirical validation of a defense support system.

Sage's current policy exempts language, grammar, and structural assistance from disclosure, but explicitly requires disclosure of AI assistance with literature reviews and reference compilation. The acknowledgment therefore describes the original assistance and the current literature work separately. The author remains responsible for the final manuscript. [J2]

## Numerical verification in this revision

The 39 supplied verification checks passed in an isolated copy. Exact rational checks passed for 119 attaining laws, together with 60,928 finite integer checks supplementing the global algebraic argument. The exact computational phase was rerun, including all 324 sensitivity cells and the enumeration of 436 feasible main-case vertices. Eight retained output tables were compared: their numeric values and nonnumeric fields matched exactly.

The research scripts, constructed inputs, original result files, figures, and frozen protocol were retained. The original 12-million-cycle and 192,000-path Monte Carlo studies were not rerun during this editorial revision. No new operational data or experiments have been invented. The reproducibility package includes the detailed check record in results/revision_checks.json.

## JDMS preparation checks

The official submission instructions were checked on 11 October 2026 UTC. These checks distinguish document requirements that can be verified from author declarations and unresolved publisher instructions. [J1]

| Requirement | Treatment |
|:--|:--|
| Journal scope | Explicit defense-support modeling and validation question; field calibration remains outside the study |
| Length | JDMS prefers 10-20 pages but states no hard length limit; the final typeset manuscript has 12 pages |
| Structured abstract | Purpose, Methods, Results, and Conclusion; 150-200-word requirement checked |
| Keywords | Seven specific keywords after the abstract |
| Source format | Editable Word manuscript and portable LaTeX source supplied; equations remain editable |
| Manuscript elements | Title and author details, abstract, keywords, text, declarations, appendix, references, four tables, and five captioned figures |
| Figure preparation | Consecutive numbering; original 360-dpi PNGs and editable SVGs retained |
| References | Sage Vancouver numbering in order of first appearance; 28 matched bibliography entries |
| Reporting | Study-specific STRESS/ADEMP reporting map retained; no clinical-study checklist is asserted to apply |
| Declarations | Ethical considerations, participation consent, publication consent, conflicts, funding, and data availability headings included |
| Author metadata | ORCID 0009-0002-9414-7443 included; the author links the identifier in Sage Track |
| Source availability | Reproducibility package prepared; no public repository DOI or URL has been invented |

The Word submission file places tables and figures after the references. The two-column PDF is a typeset author manuscript; it does not include an invented journal volume, DOI, acceptance date, or publisher copyright statement. The Sage class is retained unchanged. Page counts and structural checks are recorded in docs/document_verification.json for the final files.

## Matters requiring the author or journal

The author confirmed no funding and no conflicts of interest and supplied ORCID 0009-0002-9414-7443. Both manuscript formats contain these final declarations. Submission-system confirmations concerning affiliation, author consent, originality, publication history, and permissions are completed by the author.

The JDMS page contradicts itself on preprints: the summary says they are accepted, while a dedicated subsection says they are not. It likewise both permits online supplemental material and states that JDMS does not currently accept supplemental files. Seek a written editorial answer if either applies. Essential evidence is included in the manuscript; the ZIP should not be assumed to be an accepted supplemental upload. [J1]

The final manuscript contains no editorial placeholders. The PDF, editable Word manuscript, and source package contain the same revised research text and final declarations. No manuscript submission, journal contact, preprint posting, or public deposit was performed. The author completes Sage Track account linking and submission certifications; the journal determines acceptance.

## Official sources

[J1] The Journal of Defense Modeling and Simulation. Submission guidelines. https://journals.sagepub.com/author-instructions/dms (accessed 11 October 2026 UTC).

[J2] Sage. Artificial intelligence policy. https://www.sagepub.com/journals/publication-ethics-policies/artificial-intelligence-policy (accessed 11 October 2026 UTC).

The paper-level references and source-access details are in docs/references.json and docs/citation_ledger.csv.
