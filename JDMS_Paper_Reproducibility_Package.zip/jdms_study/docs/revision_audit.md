# Revision audit

Revision date: 11 October 2026 UTC. Inputs: the attached manuscript PDF and reproducibility ZIP. The two supplied manuscript PDFs differed in bytes but had identical extracted text.

## Completed changes

- Corrected the acknowledgment and all ancillary authorship descriptions using the author's account: original assistance was grammar, language flow, and mathematical checking, followed by independent expert review.
- Disclosed the additional literature assistance actually used in this revision separately.
- Expanded the narrative review from 19 to 28 published references, with closer comparison to discrete stop-loss, moment-LP, service-constraint, disruption-inventory, and simulation-input literature.
- Described the mathematical certificate as a worked application of established moment-bound methods.
- Rebuilt the editable DOCX, typeset PDF, numbered Markdown, portable LaTeX, and companion strategy PDF from current sources.
- Preserved the scientific scripts, original numerical outputs, frozen protocol, and five original figures.

## Literature search record

Consensus queries included: inventory supply disruptions outage duration distribution mean variance reserve stock moment bounds distributionally robust; supply disruptions inventory duration distribution; and bounds stop-loss moments. One attempted search was rate-limited, then a later search completed. Consensus full records were fetched for the cited Arreola-Risa and DeCroix, Timonina-Farkas and colleagues, and Courtois and Denuit results before use.

Undermind ran the completed search Reserve decisions under moment matched supply outages, returning 112 ranked papers. The full research goal specified independent alternating supply spells, matched diagnostics, expected shortage, sharp moment bounds, the integer-duration certificate, and the restoration test. Workspace: https://app.undermind.ai/projects/3ba1e952-6688-4220-bca1-82baee9836bb . Search: https://app.undermind.ai/projects/3ba1e952-6688-4220-bca1-82baee9836bb?path=/Reserve%20decisions%20under%20moment%20matched%20supply%20outages .

The search used abstracts and metadata for discovery, followed by publisher and author-institution evidence for inclusion. A full-text Undermind read of Balcioglu and Gurler verified that selected equal-mean scenarios changed variance. The Courtois and Denuit institutional working paper and the Schmitt and colleagues author manuscript were inspected selectively. Access and claim support for every citation are in citation_ledger.csv. The review is not systematic and does not prove global priority.

## Verification executed

Commands were run in an isolated copy: python src/verify.py; python src/verify_certificates.py; python src/study.py --phase exact. The 39 supplied checks passed; the exact certificate passed 119 attaining-law checks and 60,928 integer checks. Eight exact-output tables, including all 324 sensitivity cells, matched the retained numeric and categorical values exactly. The original Monte Carlo studies were not rerun. Detailed results: results/revision_checks.json.

## Submission status

The structured abstract, keywords, reference correspondence, editable equations, figure resolution, disclosures, and all generated formats are checked in document_verification.json. The author confirmed no funding and no conflicts of interest and supplied ORCID 0009-0002-9414-7443. The final files include these declarations and no editorial placeholders. The author completes the submission-system declarations concerning affiliation, rights, prior publication, and final approval. Official preprint and supplement rules are internally inconsistent. No external submission, publication, journal contact, or public deposit was performed.


## Finalization

The supplied ORCID has a valid check digit and is included as a linked identifier. This format check does not authenticate ownership; Sage Track account linking is performed by the author. Demonstrated results are stated directly, and scientific assumptions and limitations are retained.
