# Study-specific reporting map

This map is informed by STRESS (Monks et al., 2019) and ADEMP (Morris et al., 2019). It is not an official completed journal checklist or a certification. The current journal-specific upload requirement should be checked before submission.

| Reporting item | Location / evidence |
|---|---|
| Decision and primary question | Manuscript section 1 |
| Relationship to closest prior work | Section 2; Table 1 |
| Generating process and independent units | Sections 3.1, 5.2, 5.3 |
| Event sequence and inventory restoration | Sections 3.1, 5.3; `daily_sim` |
| Inputs, units, and origin | Table 2; all inputs explicitly constructed |
| Estimand and performance threshold | Equations 1–2; fraction of unfilled requests |
| Outage distributions and matched statistics | Sections 3.3, 4.1 |
| Assumptions and excluded features | Sections 3.1, 8 |
| Analytical and optimization methods | Sections 4.2–4.3, 5.2; equations 5–7 |
| Post-run analytical extension | Section 4.3; exact rational certificate checker; execution notes |
| Factor levels and complete design | Section 5.1; protocol; grid CSV |
| Replications and horizons | Sections 5.2–5.3 |
| Initialization and terminal effects | Section 5.3; section 6.5 |
| Random number control and pairing | Section 5.3; seed keys in source |
| Monte Carlo uncertainty | Equation 9; approximate pointwise intervals; zero-variance reporting note |
| Independent computational checks | Section 6.4; verification report |
| Exact versus simulated outcomes | Section 6; exact and stochastic result files |
| Sensitivity and assumption challenge | Sections 6.3, 6.5 |
| Applicability and external validity | Sections 7–8 |
| Availability of code and outputs | Data availability; private package |
| Deviations and provenance | Execution notes; environment and manifest |

Primary sources: https://doi.org/10.1080/17477778.2018.1442155 and https://doi.org/10.1002/sim.8086
