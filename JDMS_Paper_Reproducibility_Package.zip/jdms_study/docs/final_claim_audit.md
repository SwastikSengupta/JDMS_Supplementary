# Final claim and source audit

Audit date: 10 October 2026. This is a computational and documentary audit, not external peer review or field validation.

## Central claim

For the stated full-restoration support-node model, matching availability, one-step transition probabilities, and the first two outage moments does not determine the smallest reserve meeting a request-loss target. The exact counterexamples prove this existence claim. No claim is made about how frequently this problem occurs in operational models.

## Checks against the retained evidence

| Claim | Evidence and outcome |
|---|---|
| A and B have identical diagnostics | Exact rational moments and finite circular traces are checked by `src/verify.py`. Both laws have mean 4 and second moment 28; the common normal-spell law gives availability 0.8, transition probabilities 1/16 and 1/4, lag-one correlation 0.6875, and the stated main-case variance coefficient. |
| A and B require 10 and 14 units | Exact expected excess-demand calculations in `results/choices.csv`; preceding integer stocks fail the 1% requirement. |
| G selects 11 and understates B's loss | G predicts 0.8447%; B's exact loss at 11 is 1.9231%. The difference exceeds half of B's true benchmark loss. |
| Bounded extreme reserve requirements are 6 and 19 | Main 32-day LP bounds, feasible attaining distributions, and independent enumeration of 436 vertices. There are 147 stock-demand combinations and both objective directions are checked. |
| Nineteen remains sharp without a duration cap | Section 4.3 supplies a quadratic majorant valid for all positive integer durations and a feasible attaining law for every integer stock at least 10. The exact upper losses at 18 and 19 are 3/290 and 3/310. `src/verify_certificates.py` uses rational arithmetic to check 119 attaining laws. The algebraic factorization proves the global result; 60,928 finite spot checks do not substitute for that proof. |
| Four is the minimum compatible reserve without a cap | Expected positive excess is at least mean duration minus stock, ruling out stocks 0–3. A law at durations 3, 4, and 63 with probabilities 1/5, 47/59, and 1/295 has the required moments and exactly 1% loss at stock 4. |
| Maximum entropy is not certified in 250 of 324 cells | Recomputed from every row of `results/sensitivity_grid.csv`. The maximum loss/target ratio is 4.285714; median added stock is 2; maximum added stock is 46. These are designed-grid summaries. |
| Simulation uncertainty is smaller than the main model disagreement | Stored batch estimates reproduce the stated point estimates and intervals. The independent units are batches or replications. Intervals are approximate, pointwise, and conditional on the known input law. |
| Limited replenishment can invalidate the baseline stock decision | Stored 365-day replications give 0.7402% loss for B at stock 14 with unlimited replenishment and 1.0674% with capacity 2. The latter interval is 1.0295–1.1053%. The finite-horizon experiment starts full in a new normal spell. |
| Numerical work was executed | Retained outputs include 12 million complete cycles, 192,000 finite-horizon replications, additional long daily checks, seeds, environment versions, source hashes, all grid cells, and verification reports. The original 39 checks passed again during revision. |

## Corrections made

Two rounded diagnostics in the original prose were corrected from the retained numerical files. The largest LP/enumeration discrepancy is 2.1014301410104963 × 10^-12, reported as 2.10 × 10^-12. The largest absolute standardized daily discrepancy is 1.7633566253171848, reported as 1.76. No reserve selection, shortage estimate, simulation path, or substantive conclusion changed.

The interval description now explicitly says “approximate.” The analytical extension is identified as work done after the original runs. The original run specification remains unchanged and is not described as a preregistration.

## Reference and novelty audit

The revised manuscript cites 28 published works. The original 19 were reconciled with their retained primary-source and DOI records and refreshed discovery metadata. Nine additional references were identified through Consensus and Undermind, then checked against publisher or author-institution records. The expanded discussion directly credits discrete stop-loss bounds, discrete moment linear programming, and inventory service constraints as established methods. The contribution is the worked simulation-validation benchmark and its stated guarantee, not a new general inventory or moment-optimization theory.

See `citation_ledger.csv` for each source's access level and the exact claim it supports. Full-text inspection is distinguished from abstract-level support; no complete full-text audit is claimed. The Courtois and Denuit institutional working paper was inspected for methodological context and the published 2009 article is cited. The Ninh article uses its 2019 issue year, rather than its 2018 online date. The review is a targeted narrative review, not a systematic review or proof of global priority.

## Authorship and final declarations

Swastik Sengupta is the sole listed author. The author states that the research and original manuscript are the author's work and that AI was used only for grammar, language flow, and mathematics checking before independent expert review. This corrected account replaces inaccurate descriptions in previous iterations. The current revision also discloses the literature assistance actually used. The reported expert review concerns mathematics, not operational validation; no such validation is claimed.

The author confirmed no funding and no conflicts of interest and supplied ORCID 0009-0002-9414-7443. These statements are included in the final manuscript. Publication history, permissions, and the final submission declarations cannot be inferred from the manuscript. The journal's official page gives contradictory directions about preprints and supplemental files. No external submission, public data deposit, or editorial inquiry was performed.

Layout and structural checks are recorded in `document_verification.json`. The editable DOCX, LaTeX source, numbered Markdown, and two-column PDF are rebuilt from the same scientific source. The separately uploaded PDF and packaged PDF contained identical extracted text before revision; both delivery routes now use the same rebuilt PDF bytes.
